<?php

namespace itoozh\AbilityItems\Commands;

use itoozh\AbilityItems\entity\NPCEntity;
use itoozh\AbilityItems\Items\BoneAbility;
use itoozh\AbilityItems\Items\CloseCallAbility;
use itoozh\AbilityItems\Items\CobwebEggAbility;
use itoozh\AbilityItems\Items\EffectDisablerAbility;
use itoozh\AbilityItems\Items\FairFightAbility;
use itoozh\AbilityItems\Items\FocusModeAbility;
use itoozh\AbilityItems\Items\FreezerAbility;
use itoozh\AbilityItems\Items\InventoryCloggerAbility;
use itoozh\AbilityItems\Items\PotionRefillAbility;
use itoozh\AbilityItems\Items\PumpkinAbility;
use itoozh\AbilityItems\Items\RottenEggAbility;
use itoozh\AbilityItems\Items\SamuraiAbility;
use itoozh\AbilityItems\Items\SoupBowlAbility;
use itoozh\AbilityItems\Items\NinjaStarAbility;
use itoozh\AbilityItems\Items\RageBrickAbility;
use itoozh\AbilityItems\Items\ResistanceAbility;
use itoozh\AbilityItems\Items\RocketAbility;
use itoozh\AbilityItems\Items\StarvingFleshAbility;
use itoozh\AbilityItems\Items\StrengthAbility;
use itoozh\AbilityItems\Items\StormBreakerAbility;
use itoozh\AbilityItems\Items\SwitcherAbility;
use itoozh\AbilityItems\Items\ThorAbility;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;


class AbilitysCommand extends Command
{
    public function __construct()
    {
        parent::__construct("abilitys", "Use this command to get all the special items or to spawn the NPC");
        $this->setPermission('ability.command');
    }

    public static function getRandomAbility(Player $sender)
    {
            $value = mt_rand(0,22);
            switch ($value)
            {
                case 0:
                    $sender->getInventory()->addItem(new StrengthAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Strength Ability§r§7 from a Partner Package!");
                    break;
                case 1:
                    $sender->getInventory()->addItem(new ResistanceAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Resistance Ability§r§7 from a Partner Package!");
                    break;
                case 2:
                    $sender->getInventory()->addItem(new RocketAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Rocket Ability§r§7 from a Partner Package!");
                    break;
                case 3:
                    $sender->getInventory()->addItem(new CloseCallAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Close Call Ability§r§7 from a Partner Package!");
                    break;
                case 4:
                    $sender->getInventory()->addItem(new EffectDisablerAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Effect Disabler Ability§r§7 from a Partner Package!");
                    break;
                case 5:
                    $sender->getInventory()->addItem(new InventoryCloggerAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Inventory Clogger Ability§r§7 from a Partner Package!");
                    break;
                case 6:
                    $sender->getInventory()->addItem(new StarvingFleshAbility());#ya
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Starving Flesh Ability§r§7 from a Partner Package!");
                    break;
                case 7:
                    $sender->getInventory()->addItem(new SoupBowlAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Soup Bow lAbility§r§7 from a Partner Package!");
                    break;
                case 8:
                    $sender->getInventory()->addItem(new NinjaStarAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Ninja Star Ability§r§7 from a Partner Package!");
                    break;
                case 9:
                    $sender->getInventory()->addItem(new RageBrickAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Rage Brick Ability§r§7 from a Partner Package!");
                    break;
                case 10:
                    $sender->getInventory()->addItem(new SwitcherAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Switcher Ability§r§7 from a Partner Package!");
                    break;
                case 11:
                    $sender->getInventory()->addItem(new BoneAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Bone Ability§r§7 from a Partner Package!");
                    break;
                case 12:
                    $sender->getInventory()->addItem(new FreezerAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Freezer Ability§r§7 from a Partner Package!");
                    break;
                case 13:
                    $sender->getInventory()->addItem(new RottenEggAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Rotten Egg Ability§r§7 from a Partner Package!");
                    break;
                case 14:
                    $sender->getInventory()->addItem(new PotionRefillAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Potion Refill Ability§r§7 from a Partner Package!");
                    break;
                case 15:
                    $sender->getInventory()->addItem(new StormBreakerAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Storm Breaker Ability§r§7 from a Partner Package!");
                    break;
                case 16:
                    $sender->getInventory()->addItem(new ThorAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Thor Ability§r§7 from a Partner Package!");
                    break;
                case 17:
                    $sender->getInventory()->addItem(new CobwebEggAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Cobweb Egg Ability§r§7 from a Partner Package!");
                    break;
                case 18:
                    $sender->getInventory()->addItem(new PumpkinAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Pumpkin Ability§r§7 from a Partner Package!");
                    break;
                case 19:
                    $sender->getInventory()->addItem(new FairFightAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Fair Fight Ability§r§7 from a Partner Package!");
                    break;
                case 20:
                    $sender->getInventory()->addItem(new FocusModeAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Focus Mode Ability§r§7 from a Partner Package!");
                    break;
                case 21:
                    $sender->getInventory()->addItem(new SamuraiAbility());
                    $sender->sendMessage("§l§7[§6!§7] - §r§7You have received §6Samurai Ability§r§7 from a Partner Package!");
                    break;
            }
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {

        if (!$sender instanceof Player) {
            return;
        }
        if (!$this->testPermission($sender)) {
            return;
        }
        if (!isset($args[0])) {
            $sender->sendMessage('§r§7---------------------------------------------');
            $sender->sendMessage('§r ');
            $sender->sendMessage('§r§1§lAbilityItems');
            $sender->sendMessage('§r§1Version§f:§r§2 1.0.0');
            $sender->sendMessage('§r§1Author§f:§r§2 Michelle');
            $sender->sendMessage('§r§r ');
            $sender->sendMessage('§r§2/abilitys npc §f- §1Use this command to spawn the NPC from AbilityItems.');
            $sender->sendMessage('§r§2/abilitys giveall §f- §1Use this command to get all AbilityItems.');
            $sender->sendMessage('§r§2/partneritems §f- §1Use this command to open a menu so you can see all available AbilityItems.');
            $sender->sendMessage('§r  ');
            $sender->sendMessage('§r§7---------------------------------------------');
            return;
        }
        if (strtolower($args[0]) === 'giveall') {
            if (!isset($args[1])) {
                $sender->getInventory()->addItem(new StrengthAbility());
                $sender->getInventory()->addItem(new ResistanceAbility());
                $sender->getInventory()->addItem(new RocketAbility());
                $sender->getInventory()->addItem(new CloseCallAbility());
                $sender->getInventory()->addItem(new EffectDisablerAbility());
                $sender->getInventory()->addItem(new InventoryCloggerAbility());
                $sender->getInventory()->addItem(new StarvingFleshAbility());#ya
                $sender->getInventory()->addItem(new SoupBowlAbility());
                $sender->getInventory()->addItem(new NinjaStarAbility());
                $sender->getInventory()->addItem(new RageBrickAbility());
                $sender->getInventory()->addItem(new SwitcherAbility());
                $sender->getInventory()->addItem(new BoneAbility());
                $sender->getInventory()->addItem(new FreezerAbility());
                $sender->getInventory()->addItem(new RottenEggAbility());
                $sender->getInventory()->addItem(new PotionRefillAbility());
                $sender->getInventory()->addItem(new StormBreakerAbility());
                $sender->getInventory()->addItem(new ThorAbility());
                $sender->getInventory()->addItem(new CobwebEggAbility());
                $sender->getInventory()->addItem(new PumpkinAbility());
                $sender->getInventory()->addItem(new FairFightAbility());
                $sender->getInventory()->addItem(new FocusModeAbility());
                $sender->getInventory()->addItem(new SamuraiAbility());
                $sender->sendMessage(TextFormat::colorize('§r§aAbility items give successfully!'));
                return;
            }
        }
        if (strtolower($args[0]) === 'npc') {
            if (!isset($args[1])) {
                $entity = NPCEntity::create($sender);
                $entity->spawnToAll();
                $sender->sendMessage(TextFormat::colorize('§r§aNPC created successfully!'));
            }
        }
    }
}

