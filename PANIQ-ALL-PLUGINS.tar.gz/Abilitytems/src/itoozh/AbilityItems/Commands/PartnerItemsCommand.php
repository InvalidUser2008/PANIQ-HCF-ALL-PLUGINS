<?php

namespace itoozh\AbilityItems\Commands;

use itoozh\AbilityItems\Items\BoneAbility;
use itoozh\AbilityItems\Items\CloseCallAbility;
use itoozh\AbilityItems\Items\CobwebEggAbility;
use itoozh\AbilityItems\Items\EffectDisablerAbility;
use itoozh\AbilityItems\Items\FairFightAbility;
use itoozh\AbilityItems\Items\FocusModeAbility;
use itoozh\AbilityItems\Items\FreezerAbility;
use itoozh\AbilityItems\Items\InventoryCloggerAbility;
use itoozh\AbilityItems\Items\PotionRefillAbility;
use itoozh\AbilityItems\Items\PrePearAbility;
use itoozh\AbilityItems\Items\PumpkinAbility;
use itoozh\AbilityItems\Items\RottenEggAbility;
use itoozh\AbilityItems\Items\SamuraiAbility;
use itoozh\AbilityItems\Items\SoupBowlAbility;
use itoozh\AbilityItems\Items\NinjaStarAbility;
use itoozh\AbilityItems\Items\RageBrickAbility;
use itoozh\AbilityItems\Items\ResistanceAbility;
use itoozh\AbilityItems\Items\RocketAbility;
use itoozh\AbilityItems\Items\StarvingFleshAbility;
use itoozh\AbilityItems\Items\StrengthAbility;
use itoozh\AbilityItems\Items\StormBreakerAbility;
use itoozh\AbilityItems\Items\SwitcherAbility;
use itoozh\AbilityItems\Items\ThorAbility;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;


class PartnerItemsCommand extends Command
{
    public function __construct()
    {
        parent::__construct("partneritems", "Use this for look all Ability Items");

    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender instanceof Player) {
            return;
        }

        if (!isset($args[0])) {
            $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
            $menu->setName("§r§r§r§l§6Ability Items");
            $menu->getInventory()->setContents([
                0 => new RottenEggAbility(),
                1 => new StrengthAbility(),
                2 => new ResistanceAbility(),
                3 => new RocketAbility(),
                4 => new CloseCallAbility(),
                5 => new EffectDisablerAbility(),
                6 => new InventoryCloggerAbility(),
                7 => new StarvingFleshAbility(),
                8 => new SoupBowlAbility(),
                9 => new NinjaStarAbility(),
                10 => new RageBrickAbility(),
                11 => new SwitcherAbility(),
                12 => new BoneAbility(),
                13 => new FreezerAbility(),
                14 => new PotionRefillAbility(),
                15 => new StormBreakerAbility(),
                16 => new PrePearAbility(),
                17 => new ThorAbility(),
                18 => new CobwebEggAbility(),
                19 => new PumpkinAbility(),
                20 => new FairFightAbility(),
                21 => new FocusModeAbility(),
                22 => new SamuraiAbility(),

            ]);

            $menu->setListener(function (InvMenuTransaction $transaction): InvMenuTransactionResult {
                $player = $transaction->getPlayer();
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "c§l§6Rotten Egg§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new RottenEggAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Strength II§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new StrengthAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Resistance III§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new ResistanceAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Rocket§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new RocketAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Close Call§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new CloseCallAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Effect Disabler§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new EffectDisablerAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Inventory Clogger§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new InventoryCloggerAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Starving Flesh§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new StarvingFleshAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Soup Bowl§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new SoupBowlAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§5Ninja Star§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new NinjaStarAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Rage Brick§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new RageBrickAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Switcher§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new SwitcherAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Bone§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new BoneAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Freezer§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new FreezerAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Potion Refill§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new PotionRefillAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Storm Breaker§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new StormBreakerAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6PrePearl§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new PrePearAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Thor§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new ThorAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Cobweb Egg§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new CobwebEggAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Pumpkin§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new PumpkinAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Fair Fight§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new FairFightAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Focus Mode§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new FocusModeAbility());
                }
                if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§4Samurai§r§r§r") {
                    if (!$player->hasPermission("ability.command")) {
                        return $transaction->discard();
                    }
                    $player->getInventory()->addItem(new SamuraiAbility());
                }
                return $transaction->discard();

            });
            $menu->send($sender);
        }
    }
}
