<?php

namespace itoozh\AbilityItems\Listener;

use itoozh\AbilityItems\Items\BoneAbility;
use itoozh\AbilityItems\Items\CloseCallAbility;
use itoozh\AbilityItems\Items\CobwebEggAbility;
use itoozh\AbilityItems\Items\EffectDisablerAbility;
use itoozh\AbilityItems\Items\FairFightAbility;
use itoozh\AbilityItems\Items\FocusModeAbility;
use itoozh\AbilityItems\Items\FreezerAbility;
use itoozh\AbilityItems\Items\InventoryCloggerAbility;
use itoozh\AbilityItems\Items\NinjaStarAbility;
use itoozh\AbilityItems\Items\PotionRefillAbility;
use itoozh\AbilityItems\Items\PrePearAbility;
use itoozh\AbilityItems\Items\PumpkinAbility;
use itoozh\AbilityItems\Items\RageBrickAbility;
use itoozh\AbilityItems\Items\ResistanceAbility;
use itoozh\AbilityItems\Items\RocketAbility;
use itoozh\AbilityItems\Items\RottenEggAbility;
use itoozh\AbilityItems\Items\SamuraiAbility;
use itoozh\AbilityItems\Items\SoupBowlAbility;
use itoozh\AbilityItems\Items\StarvingFleshAbility;
use itoozh\AbilityItems\Items\StormBreakerAbility;
use itoozh\AbilityItems\Items\StrengthAbility;
use itoozh\AbilityItems\Items\SwitcherAbility;
use itoozh\AbilityItems\Items\ThorAbility;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\utils\TextFormat;


class PartnerPackageListener implements Listener
{
    public function onItemUse(PlayerItemUseEvent $event): void
    {
        $player = $event->getPlayer();
        $item = $event->getItem();

        switch ($item->getCustomName()) {
            case TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "Partner Package":
                $items = [
                    new RottenEggAbility(),
                    new StrengthAbility(),
                    new ResistanceAbility(),
                    new RocketAbility(),
                    new CloseCallAbility(),
                    new EffectDisablerAbility(),
                    new InventoryCloggerAbility(),
                    new StarvingFleshAbility(),
                    new SoupBowlAbility(),
                    new NinjaStarAbility(),
                    new RageBrickAbility(),
                    new SwitcherAbility(),
                    new BoneAbility(),
                    new FreezerAbility(),
                    new PotionRefillAbility(),
                    new StormBreakerAbility(),
                    new PrePearAbility(),
                    new ThorAbility(),
                    new CobwebEggAbility(),
                    new PumpkinAbility(),
                    new FairFightAbility(),
                    new FocusModeAbility(),
                    new SamuraiAbility(),
                ];
                $randomItem = $items[array_rand($items)];
                $player->getInventory()->addItem($randomItem);
                $player->sendMessage("§r§r§r§l§6Package Abierta");
                $item->pop();
                $player->getInventory()->setItemInHand($item);
                break;

        }
    }
}