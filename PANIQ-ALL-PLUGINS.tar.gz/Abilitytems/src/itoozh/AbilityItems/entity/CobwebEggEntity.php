<?php

namespace itoozh\AbilityItems\entity;

use pocketmine\entity\projectile\Egg;

class CobwebEggEntity extends Egg
{
}