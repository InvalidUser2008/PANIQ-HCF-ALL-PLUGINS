<?php

declare(strict_types=1);

namespace itoozh\AbilityItems\entity;

use itoozh\AbilityItems\Items\BoneAbility;
use itoozh\AbilityItems\Items\CloseCallAbility;
use itoozh\AbilityItems\Items\CobwebEggAbility;
use itoozh\AbilityItems\Items\EffectDisablerAbility;
use itoozh\AbilityItems\Items\FairFightAbility;
use itoozh\AbilityItems\Items\FocusModeAbility;
use itoozh\AbilityItems\Items\FreezerAbility;
use itoozh\AbilityItems\Items\InventoryCloggerAbility;
use itoozh\AbilityItems\Items\NinjaStarAbility;
use itoozh\AbilityItems\Items\PotionRefillAbility;
use itoozh\AbilityItems\Items\PrePearAbility;
use itoozh\AbilityItems\Items\PumpkinAbility;
use itoozh\AbilityItems\Items\RageBrickAbility;
use itoozh\AbilityItems\Items\ResistanceAbility;
use itoozh\AbilityItems\Items\RocketAbility;
use itoozh\AbilityItems\Items\RottenEggAbility;
use itoozh\AbilityItems\Items\SamuraiAbility;
use itoozh\AbilityItems\Items\SoupBowlAbility;
use itoozh\AbilityItems\Items\StarvingFleshAbility;
use itoozh\AbilityItems\Items\StrengthAbility;
use itoozh\AbilityItems\Items\StormBreakerAbility;
use itoozh\AbilityItems\Items\SwitcherAbility;
use itoozh\AbilityItems\Items\ThorAbility;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\entity\Human;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;

class NPCEntity extends Human
{

    /** @var int|null */

    /**
     * @param Player $player
     *
     * @return \itoozh\AbilityItems\entity\NPCEntity
     */
    public static function create(Player $player): self
    {
        $nbt = CompoundTag::create()
            ->setTag("Pos", new ListTag([
                new DoubleTag($player->getLocation()->x),
                new DoubleTag($player->getLocation()->y),
                new DoubleTag($player->getLocation()->z)
            ]))
            ->setTag("Motion", new ListTag([
                new DoubleTag($player->getMotion()->x),
                new DoubleTag($player->getMotion()->y),
                new DoubleTag($player->getMotion()->z)
            ]))
            ->setTag("Rotation", new ListTag([
                new FloatTag($player->getLocation()->yaw),
                new FloatTag($player->getLocation()->pitch)
            ]));
        return new self($player->getLocation(), $player->getSkin(), $nbt);
    }

    /**
     * @param int $currentTick
     *
     * @return bool
     */
    public function onUpdate(int $currentTick): bool
    {
        $parent = parent::onUpdate($currentTick);

        $this->setNameTag(TextFormat::colorize("§r§6Partner Item\n§r§7/items"));
        $this->setNameTagAlwaysVisible(true);

        return $parent;
    }

    /**
     * @param EntityDamageEvent $source
     */
    public function attack(EntityDamageEvent $source): void
    {
        $source->cancel();

        if (!$source instanceof EntityDamageByEntityEvent) {
            return;
        }

        $damager = $source->getDamager();

        if (!$damager instanceof Player) {
            return;
        }

        if ($damager->getInventory()->getItemInHand()->getId() === 276) {
            if ($damager->hasPermission('removenpc.ability')) {
                $this->kill();
            }
            return;
        }


        $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $menu->setName("§r§r§r§l§6Ability Items");
        $menu->getInventory()->setContents([
            0 => new RottenEggAbility(),
            1 => new StrengthAbility(),
            2 => new ResistanceAbility(),
            3 => new RocketAbility(),
            4 => new CloseCallAbility(),
            5 => new EffectDisablerAbility(),
            6 => new InventoryCloggerAbility(),
            7 => new StarvingFleshAbility(),
            8 => new SoupBowlAbility(),
            9 => new NinjaStarAbility(),
            10 => new RageBrickAbility(),
            11 => new SwitcherAbility(),
            12 => new BoneAbility(),
            13 => new FreezerAbility(),
            14 => new PotionRefillAbility(),
            15 => new StormBreakerAbility(),
            16 => new PrePearAbility(),
            17 => new ThorAbility(),
            18 => new CobwebEggAbility(),
            19 => new PumpkinAbility(),
            20 => new FairFightAbility(),
            21 => new FocusModeAbility(),
            22 => new SamuraiAbility(),

        ]);

        $menu->setListener(function (InvMenuTransaction $transaction): InvMenuTransactionResult {
            $player = $transaction->getPlayer();
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Rotten Egg§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new RottenEggAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Strength II§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new StrengthAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Resistance III§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new ResistanceAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Rocket§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new RocketAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Close Call§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new CloseCallAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Effect Disabler§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new EffectDisablerAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Inventory Clogger§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new InventoryCloggerAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Starving Flesh§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new StarvingFleshAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Soup Bowl§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new SoupBowlAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§5Ninja Star§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new NinjaStarAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Rage Brick§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new RageBrickAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Switcher§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new SwitcherAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Bone§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new BoneAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Freezer§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new FreezerAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Potion Refill§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new PotionRefillAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Storm Breaker§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new StormBreakerAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6PrePearl§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new PrePearAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Thor§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new ThorAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Cobweb Egg§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new CobwebEggAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Pumpkin§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new PumpkinAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Fair Fight§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new FairFightAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§6Focus Mode§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new FocusModeAbility());
            }
            if ($transaction->getItemClicked()->getCustomName() === TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "§r§r§r§l§4Samurai§r§r§r") {
                if (!$player->hasPermission("ability.command")) {
                    return $transaction->discard();
                }
                $player->getInventory()->addItem(new SamuraiAbility());
            }
            return $transaction->discard();
        });
        $menu->send($damager);
    }
}