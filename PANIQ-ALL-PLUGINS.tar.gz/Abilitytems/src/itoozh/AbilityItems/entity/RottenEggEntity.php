<?php

namespace itoozh\AbilityItems\entity;

use pocketmine\entity\projectile\Egg;

class RottenEggEntity extends Egg
{

}