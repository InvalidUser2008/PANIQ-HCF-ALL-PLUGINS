<?php

namespace itoozh\AbilityItems\entity;

use pocketmine\entity\projectile\Snowball;

class SwitcherEntity extends Snowball
{

}