<?php

namespace aqqwx;

use aqqwx\Command\CeCommand;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use pocketmine\world\World;

class Main Extends PluginBase implements Listener
{
    use SingletonTrait;

    protected function onLoad(): void
    {
        self::setInstance($this);
    }

    public function onEnable(): void {

    	$this->getServer()->getLogger()->info("CustomEnchants");

		self::$instance = $this;

		

		$this->saveDefaultConfig();

		

		$this->config = $this->getConfig()->getAll();

		

		$this->getServer()->getCommandMap()->register('cench', new CeCommand());

	}
    public function onMove(PlayerMoveEvent $event)
    {
        $player = $event->getPlayer();

        #HELMET
        if ($player->getArmorInventory()->getHelmet()->getLore() === ["§r§4Respiracion Acuatica I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::WATER_BREATHING(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getHelmet()->getLore() === ["§r§4Prisa I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::HASTE(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getHelmet()->getLore() === ["§r§cFire Resistence"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::FIRE_RESISTANCE(), 20 * 16, 2));
        }
        if ($player->getArmorInventory()->getHelmet()->getLore() === ["§r§1Vision Nocturna"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 20 * 16, 1));
        }
        if ($player->getArmorInventory()->getHelmet()->getLore() === ["§r§4Prisa IV"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::HASTE(), 20 * 16, 3));
        }
        if ($player->getArmorInventory()->getHelmet()->getLore() === ["§r§4Speed I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getHelmet()->getLore() === ["§r§4Fuerza I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::STRENGTH(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getHelmet()->getLore() === ["§r§4Fuerza II"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::STRENGTH(), 20 * 16, 1));
        }
        if ($player->getArmorInventory()->getHelmet()->getLore() === ["§r§4Invisibility"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::INVISIBILITY(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getHelmet()->getLore() === ["§r§4Speed II"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 20 * 16, 1));
        }
        if ($player->getArmorInventory()->getHelmet()->getLore() === ["§r§4Speed III"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 20 * 16, 2));
        }
        #CHESTPLATE
        if ($player->getArmorInventory()->getChestplate()->getLore() === ["§r§4Respiracion Acuatica I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::WATER_BREATHING(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getChestplate()->getLore() === ["§r§4Prisa I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::HASTE(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getChestplate()->getLore() === ["§r§cFire Resistence"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::FIRE_RESISTANCE(), 20 * 16, 2));
        }
        if ($player->getArmorInventory()->getChestplate()->getLore() === ["§r§1Vision Nocturna"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 20 * 16, 1));
        }
        if ($player->getArmorInventory()->getChestplate()->getLore() === ["§r§4Prisa IV"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::HASTE(), 20 * 16, 3));
        }
        if ($player->getArmorInventory()->getChestplate()->getLore() === ["§r§4Speed I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getChestplate()->getLore() === ["§r§4Fuerza I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::STRENGTH(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getChestplate()->getLore() === ["§r§4Fuerza II"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::STRENGTH(), 20 * 16, 1));
        }
        if ($player->getArmorInventory()->getChestplate()->getLore() === ["§r§4Invisibility"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::INVISIBILITY(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getChestplate()->getLore() === ["§r§4Speed II"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 20 * 16, 1));
        }
        if ($player->getArmorInventory()->getChestplate()->getLore() === ["§r§4Speed III"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 20 * 16, 2));
        }
        #LEGGINGS
        if ($player->getArmorInventory()->getLeggings()->getLore() === ["§r§4Respiracion Acuatica I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::WATER_BREATHING(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getLeggings()->getLore() === ["§r§4Prisa I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::HASTE(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getLeggings()->getLore() === ["§r§cFire Resistence"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::FIRE_RESISTANCE(), 20 * 16, 2));
        }
        if ($player->getArmorInventory()->getLeggings()->getLore() === ["§r§1Vision Nocturna"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 20 * 16, 1));
        }
        if ($player->getArmorInventory()->getLeggings()->getLore() === ["§r§4Prisa IV"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::HASTE(), 20 * 16, 3));
        }
        if ($player->getArmorInventory()->getLeggings()->getLore() === ["§r§4Speed I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getLeggings()->getLore() === ["§r§4Fuerza I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::STRENGTH(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getLeggings()->getLore() === ["§r§4Fuerza II"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::STRENGTH(), 20 * 16, 1));
        }
        if ($player->getArmorInventory()->getLeggings()->getLore() === ["§r§4Invisibility"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::INVISIBILITY(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getLeggings()->getLore() === ["§r§4Speed III"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 20 * 16, 2));
        }
        if ($player->getArmorInventory()->getLeggings()->getLore() === ["§r§4Speed II"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 20 * 16, 1));
        }
        #BOOTS
        if ($player->getArmorInventory()->getBoots()->getLore() === ["§r§4Respiracion Acuatica I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::WATER_BREATHING(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getBoots()->getLore() === ["§r§4Prisa I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::HASTE(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getBoots()->getLore() === ["§r§cFire Resistence"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::FIRE_RESISTANCE(), 20 * 16, 2));
        }
        if ($player->getArmorInventory()->getBoots()->getLore() === ["§r§1Vision Nocturna"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 20 * 16, 1));
        }
        if ($player->getArmorInventory()->getBoots()->getLore() === ["§r§4Prisa IV"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::HASTE(), 20 * 16, 3));
        }
        if ($player->getArmorInventory()->getBoots()->getLore() === ["§r§4Speed I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getBoots()->getLore() === ["§r§4Fuerza I"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::STRENGTH(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getBoots()->getLore() === ["§r§4Fuerza II"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::STRENGTH(), 20 * 16, 1));
        }
        if ($player->getArmorInventory()->getBoots()->getLore() === ["§r§4Invisibility"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::INVISIBILITY(), 20 * 16, 0));
        }
        if ($player->getArmorInventory()->getBoots()->getLore() === ["§r§4Speed III"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 20 * 16, 2));
        }
        if ($player->getArmorInventory()->getBoots()->getLore() === ["§r§4Speed II"]){
            $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 20 * 16, 1));
        }
    }

}