<?php

namespace itoozh\commands;

use itoozh\entity\SellEntity;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;

class CeCommand extends Command{

    public function __construct()
    {
        parent::__construct("cench", "customEnchants");
        $this->setPermission('enchant.command');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$this->testPermission($sender)) {
            return;
        }
        if (!$sender instanceof Player) {
            return;
        }
        if (strtolower($args[0]) === 'respiracion') {
            if (!isset($args[1])) {
                $item = $sender->getInventory()->getItemInHand();
                $item->setLore(["§r§4Respiracion Acuatica I"]);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§aItem Encantado con §4Respiracion Acuatica I");
            }
        }
        if (strtolower($args[0]) === 'prisa1') {
            if (!isset($args[1])) {
                $item = $sender->getInventory()->getItemInHand();
                $item->setLore(["§r§4Prisa I"]);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§aItem Encantado con §4Prisa I");
            }
        }
        if (strtolower($args[0]) === 'fire') {
            if (!isset($args[1])) {
                $item = $sender->getInventory()->getItemInHand();
                $item->setLore(["§r§cFire Resistence"]);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§aItem Encantado con §cFire Resistence");
            }
        }
        if (strtolower($args[0]) === 'prisa3') {
            if (!isset($args[1])) {
                $item = $sender->getInventory()->getItemInHand();
                $item->setLore(["§r§4Prisa III"]);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§aItem Encantado con §4Prisa III");
            }
        }
        if (strtolower($args[0]) === 'invisibility') {
            if (!isset($args[1])) {
                $item = $sender->getInventory()->getItemInHand();
                $item->setLore(["§r§4§r§4Invisibility"]);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§aItem Encantado con §4§r§4Invisibility");
            }
        }
        if (strtolower($args[0]) === 'prisa4') {
            if (!isset($args[1])) {
                $item = $sender->getInventory()->getItemInHand();
                $item->setLore(["§r§4Prisa IV"]);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§aItem Encantado con §4Prisa IV");
            }
        }
        if (strtolower($args[0]) === 'fuerza1') {
            if (!isset($args[1])) {
                $item = $sender->getInventory()->getItemInHand();
                $item->setLore(["§r§4Fuerza I"]);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§aItem Encantado con §4Fuerza I");
            }
        }
        if (strtolower($args[0]) === 'fuerza2') {
            if (!isset($args[1])) {
                $item = $sender->getInventory()->getItemInHand();
                $item->setLore(["§r§4Fuerza II"]);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§aItem Encantado con §4Fuerza II");
            }
        }
        if (strtolower($args[0]) === 'speed1') {
            if (!isset($args[1])) {
                $item = $sender->getInventory()->getItemInHand();
                $item->setLore(["§r§4Speed I"]);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§aItem Encantado con §4Speed I");
            }
        }
        if (strtolower($args[0]) === 'speed2') {
            if (!isset($args[1])) {
                $item = $sender->getInventory()->getItemInHand();
                $item->setLore(["§r§4Speed II"]);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§aItem Encantado con §4Speed II");
            }
        }
        if (strtolower($args[0]) === 'speed3') {
            if (!isset($args[1])) {
                $item = $sender->getInventory()->getItemInHand();
                $item->setLore(["§r§4Speed III"]);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§aItem Encantado con §4Speed III");
            }
        }
    }
}