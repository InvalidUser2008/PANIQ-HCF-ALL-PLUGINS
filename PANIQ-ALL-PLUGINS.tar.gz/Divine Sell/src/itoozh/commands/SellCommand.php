<?php

namespace itoozh\commands;

use itoozh\entity\SellEntity;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;

class SellCommand extends Command
{

    public function __construct()
    {
        parent::__construct("sell", "Plugin by itoozh");
        $this->setPermission('sell.command');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$this->testPermission($sender)) {
            return;
        }
        if (!$sender instanceof Player) {
            return;
        }
        if (strtolower($args[0]) === 'spawn') {
            if (!isset($args[1])) {
                $entity = SellEntity::create($sender);
                $entity->spawnToAll();
                $sender->sendMessage(TextFormat::colorize('§r§aNPC created successfully!'));
            }
        }
    }
}