<?php

namespace itoozh\entity;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\entity\Human;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\ItemFactory;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use vLiqkz\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\world\sound\ItemBreakSound;
use pocketmine\world\sound\XpCollectSound;

class SellEntity extends Human
{

    /** @var int|null */

    /**
     * @param Player $player
     *
     * @return SellEntity
     */
    public static function create(Player $player): self
    {
        $nbt = CompoundTag::create()
            ->setTag("Pos", new ListTag([
                new DoubleTag($player->getLocation()->x),
                new DoubleTag($player->getLocation()->y),
                new DoubleTag($player->getLocation()->z)
            ]))
            ->setTag("Motion", new ListTag([
                new DoubleTag($player->getMotion()->x),
                new DoubleTag($player->getMotion()->y),
                new DoubleTag($player->getMotion()->z)
            ]))
            ->setTag("Rotation", new ListTag([
                new FloatTag($player->getLocation()->yaw),
                new FloatTag($player->getLocation()->pitch)
            ]));
        return new self($player->getLocation(), $player->getSkin(), $nbt);
    }

    /**
     * @param int $currentTick
     *
     * @return bool
     */
    public function onUpdate(int $currentTick): bool
    {
        $parent = parent::onUpdate($currentTick);

        $this->setNameTag(TextFormat::colorize("§l§a* NEW *\n§r§4SellShop\n§r§l§bCosmos"));
        $this->setNameTagAlwaysVisible(true);

        return $parent;
    }

    /**
     * @param EntityDamageEvent $source
     */
    public function attack(EntityDamageEvent $source): void
    {
        $source->cancel();

        if (!$source instanceof EntityDamageByEntityEvent) {
            return;
        }

        $damager = $source->getDamager();

        if (!$damager instanceof Player) {
            return;
        }

        if ($damager->getInventory()->getItemInHand()->getId() === 276) {
            if ($damager->hasPermission('removenpc')) {
                $this->kill();
            }
            return;
        }

        if (!isset($args[0])) {
            $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
            $menu->setName("§r§7Shop");
            $cristal = ItemFactory::getInstance()->get(241, 1)->setCustomName(" ")->setLore(["§r "]);
            $menu->getInventory()->setContents([
                0 => $cristal,
                1 => $cristal,
                /*2 => $cristal,
                3 => $cristal,
                4 => $cristal,
                5 => $cristal,
                6 => $cristal,*/
                7 => $cristal,
                8 => $cristal,
                9 => $cristal,
                /*10 => $cristal,
                11 => $cristal,
                12 => $cristal,
                13 => $cristal,
                14 => $cristal,
                15 => $cristal,
                16 => $cristal,*/
                17 => $cristal,
                /*18 => $cristal,
                19 => $cristal,
                20 => $cristal,*/
                21 => ItemFactory::getInstance()->get(57, 93, 16)->setLore([" \n§r§4Price: §r§6$2500\n "]),
                22 => ItemFactory::getInstance()->get(133, 93, 16)->setLore([" \n§r§4Price: §r§6$2750\n "]),
                23 => ItemFactory::getInstance()->get(41, 93, 16)->setLore([" \n§r§4Price: §r§6$2250\n "]),
                /*24 => $cristal,
                25 => $cristal,
                26 => $cristal,
                27 => $cristal,
                28 => $cristal,
                29 => $cristal,*/
                30 => ItemFactory::getInstance()->get(42, 93, 16)->setLore([" \n§r§4Price: §r§6$2000\n "]),
                31 => ItemFactory::getInstance()->get(22, 93, 16)->setLore([" \n§r§4Price: §r§6$1750\n "]),
                32 => ItemFactory::getInstance()->get(152, 93, 16)->setLore([" \n§r§4Price: §r§6$1500\n "]),
                /*33 => $cristal,
                34 => $cristal,
                35 => $cristal,*/
                36 => $cristal,
                /*37 => $cristal,
                38 => $cristal,
                39 => $cristal,
                40 => $cristal,
                41 => $cristal,
                42 => $cristal,
                43 => $cristal,*/
                44 => $cristal,
                45 => $cristal,
                46 => $cristal,
                /*47 => $cristal,
                48 => $cristal,
                49 => $cristal,
                50 => $cristal,
                52 => $cristal,
                51 => $cristal,*/
                52 => $cristal,
                53 => $cristal,
                54 => $cristal,
            ]);

            $menu->setListener(function (InvMenuTransaction $transaction): InvMenuTransactionResult {
                $player = $transaction->getPlayer();
                if ($transaction->getItemClicked()->getId() == VanillaBlocks::REDSTONE()->asItem()->getId()) {
                    $item = null;
                    if ($player instanceof Player)
                        foreach ($player->getInventory()->getContents() as $itemInventory)
                            if ($itemInventory->equals(VanillaBlocks::REDSTONE()->asItem()))
                                $item = $itemInventory;

                    if ($item === null) {
                        $player->sendMessage("§cYou need 16 or more blocks to be able to sell them");
                        $player->getWorld()->addSound($player->getPosition(), new ItemBreakSound(), [$player]);
                        return $transaction->discard();
                    }

                    if ($item->getCount() >= 16) {
                        $player->getInventory()->removeItem($item->setCount(16));
                        $player->setBalance($player->getBalance() + 1500);
                        $player->sendMessage("§aYour new Balance is " . $player->getBalance() . "$");
                        $player->getWorld()->addSound($player->getPosition(), new XpCollectSound(), [$player]);
                    }

                    if ($item->getCount() < 16) {
                        $player->sendMessage("§cYou need to have 16 or more blocks to complete this transaction");
                        $player->getWorld()->addSound($player->getPosition(), new ItemBreakSound(), [$player]);
                    }
                }
                if ($transaction->getItemClicked()->getId() == VanillaBlocks::DIAMOND()->asItem()->getId()) {
                    $item = null;
                    if ($player instanceof Player)
                        foreach ($player->getInventory()->getContents() as $itemInventory)
                            if ($itemInventory->equals(VanillaBlocks::DIAMOND()->asItem()))
                                $item = $itemInventory;

                    if ($item === null) {
                        $player->sendMessage("§cYou need 16 or more blocks to be able to sell them");
                        $player->getWorld()->addSound($player->getPosition(), new ItemBreakSound(), [$player]);
                        return $transaction->discard();
                    }

                    if ($item->getCount() >= 16) {
                        $player->getInventory()->removeItem($item->setCount(16));
                        $player->setBalance($player->getBalance() + 2500);
                        $player->sendMessage("§aYour new Balance is " . $player->getBalance() . "$");
                        $player->getWorld()->addSound($player->getPosition(), new XpCollectSound(), [$player]);
                    }

                    if ($item->getCount() < 16) {
                        $player->sendMessage("§cYou need to have 16 or more blocks to complete this transaction");
                        $player->getWorld()->addSound($player->getPosition(), new ItemBreakSound(), [$player]);
                    }
                }
                if ($transaction->getItemClicked()->getId() == VanillaBlocks::EMERALD()->asItem()->getId()) {
                    $item = null;
                    if ($player instanceof Player)
                        foreach ($player->getInventory()->getContents() as $itemInventory)
                            if ($itemInventory->equals(VanillaBlocks::EMERALD()->asItem()))
                                $item = $itemInventory;

                    if ($item === null) {
                        $player->sendMessage("§cYou need 16 or more blocks to be able to sell them");
                        $player->getWorld()->addSound($player->getPosition(), new ItemBreakSound(), [$player]);
                        return $transaction->discard();
                    }

                    if ($item->getCount() >= 16) {
                        $player->getInventory()->removeItem($item->setCount(16));
                        $player->setBalance($player->getBalance() + 2750);
                        $player->sendMessage("§aYour new Balance is " . $player->getBalance() . "$");
                        $player->getWorld()->addSound($player->getPosition(), new XpCollectSound(), [$player]);
                    }

                    if ($item->getCount() < 16) {
                        $player->sendMessage("§cYou need to have 16 or more blocks to complete this transaction");
                        $player->getWorld()->addSound($player->getPosition(), new ItemBreakSound(), [$player]);
                    }
                }
                if ($transaction->getItemClicked()->getId() == VanillaBlocks::IRON()->asItem()->getId()) {
                    $item = null;
                    if ($player instanceof Player)
                        foreach ($player->getInventory()->getContents() as $itemInventory)
                            if ($itemInventory->equals(VanillaBlocks::IRON()->asItem()))
                                $item = $itemInventory;

                    if ($item === null) {
                        $player->sendMessage("§cYou need 16 or more blocks to be able to sell them");
                        $player->getWorld()->addSound($player->getPosition(), new ItemBreakSound(), [$player]);
                        return $transaction->discard();
                    }

                    if ($item->getCount() >= 16) {
                        $player->getInventory()->removeItem($item->setCount(16));
                        $player->setBalance($player->getBalance() + 2000);
                        $player->sendMessage("§aYour new Balance is " . $player->getBalance() . "$");
                        $player->getWorld()->addSound($player->getPosition(), new XpCollectSound(), [$player]);
                    }

                    if ($item->getCount() < 16) {
                        $player->sendMessage("§cYou need to have 16 or more blocks to complete this transaction");
                        $player->getWorld()->addSound($player->getPosition(), new ItemBreakSound(), [$player]);
                    }
                }
                if ($transaction->getItemClicked()->getId() == VanillaBlocks::GOLD()->asItem()->getId()) {
                    $item = null;
                    if ($player instanceof Player)
                        foreach ($player->getInventory()->getContents() as $itemInventory)
                            if ($itemInventory->equals(VanillaBlocks::GOLD()->asItem()))
                                $item = $itemInventory;

                    if ($item === null) {
                        $player->sendMessage("§cYou need 16 or more blocks to be able to sell them");
                        $player->getWorld()->addSound($player->getPosition(), new ItemBreakSound(), [$player]);
                        return $transaction->discard();
                    }

                    if ($item->getCount() >= 16) {
                        $player->getInventory()->removeItem($item->setCount(16));
                        $player->setBalance($player->getBalance() + 2250);
                        $player->sendMessage("§aYour new Balance is " . $player->getBalance() . "$");
                        $player->getWorld()->addSound($player->getPosition(), new XpCollectSound(), [$player]);
                    }

                    if ($item->getCount() < 16) {
                        $player->sendMessage("§cYou need to have 16 or more blocks to complete this transaction");
                        $player->getWorld()->addSound($player->getPosition(), new ItemBreakSound(), [$player]);
                    }
                }
                if ($transaction->getItemClicked()->getId() == VanillaBlocks::LAPIS_LAZULI()->asItem()->getId()) {
                    $item = null;
                    if ($player instanceof Player)
                        foreach ($player->getInventory()->getContents() as $itemInventory)
                            if ($itemInventory->equals(VanillaBlocks::LAPIS_LAZULI()->asItem()))
                                $item = $itemInventory;

                    if ($item === null) {
                        $player->sendMessage("§cYou need 16 or more blocks to be able to sell them");
                        $player->getWorld()->addSound($player->getPosition(), new ItemBreakSound(), [$player]);
                        return $transaction->discard();
                    }

                    if ($item->getCount() >= 16) {
                        $player->getInventory()->removeItem($item->setCount(16));
                        $player->setBalance($player->getBalance() + 1750);
                        $player->sendMessage("§aYour new Balance is " . $player->getBalance() . "$");
                        $player->getWorld()->addSound($player->getPosition(), new XpCollectSound(), [$player]);
                    }

                    if ($item->getCount() < 16) {
                        $player->sendMessage("§cYou need to have 16 or more blocks to complete this transaction");
                        $player->getWorld()->addSound($player->getPosition(), new ItemBreakSound(), [$player]);
                    }
                }

                return $transaction->discard();
            });
            $menu->send($damager);
        }
    }
}
