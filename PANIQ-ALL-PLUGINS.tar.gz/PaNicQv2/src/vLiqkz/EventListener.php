<?php

namespace vLiqkz;

use vLiqkz\{Loader, Factions};
use vLiqkz\player\{Player, PlayerBase};
use vLiqkz\Task\asynctask\{LoadPlayerData, SavePlayerData};
use vLiqkz\Task\Scoreboard;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TE;
use pocketmine\event\player\{PlayerJoinEvent, PlayerQuitEvent, PlayerChatEvent, PlayerMoveEvent, PlayerInteractEvent};
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\entity\EntityLevelChangeEvent;
class EventListener implements Listener {

    /**
     * EventListener Constructor.
     */
    public function __construct(){
		
    }
    
    /**
     * @param PlayerCreationEvent $event
     * @return void
     */
    public function onPlayerCreationEvent(PlayerCreationEvent $event) : void {
        $event->setPlayerClass(Player::class, true);
    }

    /**
     * @param PlayerJoinEvent $event
     * @return void
     */
    public function onPlayerJoinEvent(PlayerJoinEvent $event) : void {
        $player = $event->getPlayer();
		  $player = $event->getPlayer();
        $event->setJoinMessage(TE::GRAY."[".TE::GREEN."+".TE::GRAY."] ".TE::GREEN.$player->getName().TE::GRAY." Ingreso al servidor!");
        
        
        
        
        PlayerBase::create($player->getName());
		Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new Scoreboard($player), 20);
        Loader::getInstance()->getServer()->getAsyncPool()->submitTask(new LoadPlayerData($player->getName(), $player->getUniqueId()->toString(), Loader::getDefaultConfig("MySQL")["hostname"], Loader::getDefaultConfig("MySQL")["username"], Loader::getDefaultConfig("MySQL")["password"], Loader::getDefaultConfig("MySQL")["database"], Loader::getDefaultConfig("MySQL")["port"]));
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function onPlayerQuitEvent(PlayerQuitEvent $event) : void {
        $player = $event->getPlayer();
	 	$event->setQuitMessage(TE::GRAY."[".TE::RED."-".TE::GRAY."] ".TE:: RED.$player->getName().TE::RED." Salio del servidor!..");

        Loader::getInstance()->getServer()->getAsyncPool()->submitTask(new SavePlayerData($player->getNetworkSession()->getIp(), Factions::inFaction($player->getName()) ? Factions::getFaction($player->getName()) : "This player not have faction", Loader::getDefaultConfig("MySQL")["hostname"], Loader::getDefaultConfig("MySQL")["username"], Loader::getDefaultConfig("MySQL")["password"], Loader::getDefaultConfig("MySQL")["database"], Loader::getDefaultConfig("MySQL")["port"]));         if($player instanceof Player){             $player->removePermissionsPlayer();
		}
	}
	
	/**
     * @param EntityLevelChangeEvent $event
     * @return void
     */
	/*
	Dont Working Class Not Found
	public function onEntityLevelChangeEvent(EntityLevelChangeEvent $event) : void {
		$player = $event->getEntity();
		$player->showCoordinates();
	}
    */
    /**
     * @param PlayerChatEvent $event
     * @return void
     */
    public function onPlayerChatEvent(PlayerChatEvent $event) : void {
    	$player = $event->getPlayer();
    	$format = null;
		if(!$player instanceof Player) return;
    	if($player->getRank() === null||$player->getRank() === "Guest"){
            $format = TE::GRAY."[".TE::GREEN."Guest".TE::GRAY."] ".TE::GRAY.$player->getName().TE::WHITE;
        }
    	if($player->getRank() === "Owner"){
    		$format = TE::GRAY."[".TE::DARK_RED."Owner".TE::GRAY."] ".TE::GRAY."[".TE::BOLD.TE::RED."♥".TE::RESET.TE::GRAY."] ".TE::GOLD.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Co-Owner"){
    		$format = TE::DARK_GRAY."[".TE::RED."Co-Owner".TE::DARK_GRAY."] ".TE::RED.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Admin"){
    		$format = TE::DARK_GRAY."[".TE::AQUA."Admin".TE::DARK_GRAY."] ".TE::GREEN.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Founder"){
    		$format = TE::DARK_GRAY."[".TE::DARK_PURPLE."§0Founder".TE::DARK_GRAY."] ".TE::DARK_PURPLE.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Mod"){
    		$format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE."Mod".TE::DARK_GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Coordinator"){
    		$format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE."Coordinator".TE::DARK_GRAY."] ".TE::DARK_AQUA.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Sr-Admin"){
    		$format = TE::DARK_GRAY."[".TE::AQUA."Sr-Admin".TE::DARK_GRAY."] ".TE::AQUA.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Modplus"){
    		$format = TE::DARK_GRAY."[".TE::DARK_AQUA."Mod+".TE::DARK_GRAY."] ".TE::DARK_AQUA.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Trainee"){
    		$format = TE::DARK_GRAY."[".TE::YELLOW."Trainee".TE::DARK_GRAY."] ".TE::YELLOW.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Developer"){
    		$format = TE::DARK_GRAY."[".TE::YELLOW."§cDeveloper".TE::DARK_GRAY."] ".TE::YELLOW.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Prime"){
    		$format = TE::DARK_GRAY."[".TE::RED."§7Prime" .TE::DARK_GRAY."] ".TE::RED.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "God"){
    		$format = TE::DARK_GRAY."[".TE::GOLD."§eGod".TE::DARK_GRAY."] ".TE::YELLOW.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Xtra"){
    		$format = TE::DARK_GRAY."[".TE::DARK_PURPLE."§bDios".TE::RESET.TE::DARK_GRAY."] ".TE::DARK_RED.$player->getName().TE::WHITE;
		}
		if($player->getRank() === "Panicq"){
    		$format = TE::DARK_GRAY."[".TE::AQUA."§l§5§kii§r§l§5PaNicQ§kii§r".TE::RESET.TE::DARK_GRAY."] ".TE::GOLD.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "NitroBooster"){
    		$format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE."NitroBooster".TE::RESET.TE::DARK_GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
    	}
        if($player->getRank() === "PlatForm-Admin"){
            $format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE."PlatForm.Admn".TE::RESET.TE::DARK_GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
        }
    	if($player->getRank() === "Panic"){
    		$format = TE::DARK_GRAY."[".TE::DARK_RED."§l§c§k!!§r§6PaNicQ§4+§c§k!!§r".TE::DARK_GRAY."] ".TE::DARK_AQUA.$player->getName().TE::WHITE;
    	}
     if($player->getRank() === "Founder"){
            $format = TE::DARK_GRAY."[".TE::DARK_RED."Founder".TE::DARK_GRAY."] ".TE::DARK_AQUA.$player->getName().TE::WHITE;
        }
    	if($player->getRank() === "Partner"){
    		$format = TE::DARK_GRAY."[".TE::OBFUSCATED.TE::YELLOW."!!".TE::RESET.TE::AQUA.TE::BOLD."Partner".TE::RESET.TE::OBFUSCATED.TE::YELLOW."!!".TE::RESET.TE::DARK_GRAY."] ".TE::AQUA.$player->getName().TE::WHITE;
    	}
        if($player->getRank() === "TikTok"){
    		$format = TE::DARK_GRAY."[".TE::OBFUSCATED.TE::YELLOW."!!".TE::RESET.TE::WHITE."Tik".TE::BLACK."Tok".TE::RESET.TE::OBFUSCATED.TE::YELLOW."!!".TE::RESET.TE::DARK_GRAY."] ".TE::AQUA.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "MiniYT"){
    		$format = TE::DARK_GRAY."[".TE::RED."Mini".TE::WHITE."YT".TE::DARK_GRAY."] ".TE::RED.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Youtuber"){
    		$format = TE::DARK_GRAY."[".TE::DARK_RED."You".TE:: DARK_RED."uber".TE::DARK_GRAY."] ".TE::DARK_RED.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Famous"){
    		$format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE.TE::BOLD."Famous".TE::RESET.TE::DARK_GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Streamer"){
    		$format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE."Twitch".TE::DARK_GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
    	}
        if($player->getRank() === "Tierra"){
            $format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE."§6Infernal".TE::DARK_GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
        }
    	if(Factions::inFaction($player->getName())){
			$factionName = Factions::getFaction($player->getName());
			$event->setFormat(TE::GRAY."[".TE::RED.$factionName.TE::GRAY."]".TE::RESET.$format." » ".$event->getMessage());
		}else{
			$event->setFormat($format." : ".$event->getMessage());
		}
	}
}

?>
