<?php

namespace vLiqkz;

use pocketmine\plugin\PluginBase;

use pocketmine\utils\Config;

use vLiqkz\crate\CrateBackup;

use vLiqkz\enchantments\{

    Enchantments,

};

use vLiqkz\provider\{

    SQLite3Provider, YamlProvider, MysqlProvider,

};

use vLiqkz\player\{

    Player,

};
use vLiqkz\API\{
    Scoreboards,
};
use vLiqkz\Task\{
	BardTask, ArcherTask, MageTask, GhostTask, 
};
use vLiqkz\Task\event\{
	FactionTask,
};
use vLiqkz\block\{
    Blocks,
};
use vLiqkz\listeners\{
	Listeners,
};
use vLiqkz\commands\{
    Commands,
};
use vLiqkz\item\{
    Items,
};
use vLiqkz\entities\{
    Entitys,
};

use vLiqkz\utils\{Data, Extensions};
use libs\muqsit\invmenu\InvMenuHandler;
use libs\muqsit\invmenu\type\util\InvMenuTypeBuilders;
use pocketmine\network\mcpe\protocol\types\inventory\WindowTypes;
use pocketmine\block\{VanillaBlocks, BlockFactory};
use vLiqkz\cooldowns\Cooldowns;

class Loader extends PluginBase {
    
    /** @var Loader */
    protected static $instance;
    /** @var Array[] */
    public static $appleenchanted = [], $rogue = [];
    
    /** @var Array[] */
	public $permission = [];
    
    /**
     * @return void
     */
    public function onLoad() : void {
        self::$instance = $this;
    }
    
    /**
     * @return void
     */
    public function onEnable(): void
    {
      if (!file_exists($this->getDataFolder()."backup")) {
    mkdir($this->getDataFolder ().'backup', 0777, true);
      }
     if (!file_exists($this->getDataFolder()."players")) {
    mkdir($this->getDataFolder ().'players', 0777, true);
      }
        if(!InvMenuHandler::isRegistered()){
            InvMenuHandler::register($this);
        }
        new Cooldowns();
        self::getServer()->getNetwork()->setName("§r§l§bCosmos§fHCF");
        MysqlProvider::connect();
        SQLite3Provider::connect();
		CrateBackup::initAll();
        Listeners::init();
        Commands::init();
        Items::init();
        Blocks::init();
        Entitys::init();
        YamlProvider::init();
        Enchantments::init();
        
        Factions::init();
        $this->getScheduler()->scheduleRepeatingTask(new BardTask(), 20);
        $this->getScheduler()->scheduleRepeatingTask(new GhostTask(), 20);
        $this->getScheduler()->scheduleRepeatingTask(new ArcherTask(), 20);
        $this->getScheduler()->scheduleRepeatingTask(new MageTask(), 20);
        $this->getScheduler()->scheduleRepeatingTask(new FactionTask(), 5 * 60 * 40);
    }
    
    /**
     * @return void
     */
    public function onDisable() : void {
        SQLite3Provider::disconnect();
        MysqlProvider::disconnect();

        YamlProvider::save();
    }

    /**
     * @return Loader
     */
    public static function getInstance() : Loader {
        return self::$instance;
    }

    /**
     * @return SQLite3Provider
     */
    public static function getProvider() : SQLite3Provider {
        return new SQLite3Provider();
    }

    /**
     * @return Scoreboards
     */
	public static function getScoreboard() : Scoreboards {
		return new Scoreboards();
    }

    /**
     * @param String $configuration
     */
    public static function getDefaultConfig($configuration){
        return self::getInstance()->getConfig()->get($configuration);
    }
    
    /**
     * @param String $configuration
     */
    public static function getConfiguration($configuration){
    	return new Config(self::getInstance()->getDataFolder()."{$configuration}.yml", Config::YAML);
    }

    /**
     * @param Player $player
     */
    public function getPermission(Player $player){
        if(!isset($this->permission[$player->getName()])){
            $this->permission[$player->getName()] = $player->addAttachment($this);
        }
        return $this->permission[$player->getName()];
    }
}

?>