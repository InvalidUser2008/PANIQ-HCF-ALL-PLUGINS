<?php

namespace vLiqkz\Task;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class GhostTagTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * GhostTagTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setGhostTagTime(Loader::getDefaultConfig("Cooldowns")["GhostTag"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
        	$this->getHandler()->cancel();
        	return;
        }
        if(!$player->isGhostTag()){
        	$this->getHandler()->cancel();
        	return;
        }
        if($player->getGhostTagTime() === 0){
            $player->setGhostTag(false);
            $this->getHandler()->cancel();
        }else{
            $player->setGhostTagTime($player->getGhostTagTime() - 1);
        }
    }
}

?>