<?php

namespace vLiqkz\Task;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class InvitationTask extends Task {

    /** @var Player */
    protected $player;

    /** @var Int */
    protected $invitationTime = 0;

    /**
     * InvitationTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $this->invitationTime = 20;
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
            $this->getHandler()->cancel();
            return;
        }
        if(!$player->isInvited()){
            $this->getHandler()->cancel();
            return;
        }
        if($this->invitationTime === 0){
            $player->setInvite(false);
            $this->getHandler()->cancel();
        }else{
            $this->invitationTime--;
        }
    }
}

?>