<?php

namespace vLiqkz\Task;

use vLiqkz\{Loader, Factions};
use vLiqkz\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class LogoutTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * LogoutTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setLogoutTime(Loader::getDefaultConfig("Cooldowns")["Logout"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
        	$this->getHandler()->cancel();
        	return;
        }
        if(!$player->isLogout()){
        	$this->getHandler()->cancel();
        	return;
        }
        if($player->getLogoutTime() === 0){
        	$player->setLogout(false);
        	$player->close("", TE::AQUA."[Logout]".TE::RESET." ".TE::GRAY."You have successfully logged out!");
            $this->getHandler()->cancel();
        }else{
            $player->setLogoutTime($player->getLogoutTime() - 1);
        }
    }
}

?>
