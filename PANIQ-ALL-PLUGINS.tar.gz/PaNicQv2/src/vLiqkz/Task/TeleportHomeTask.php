<?php

namespace vLiqkz\Task;

use vLiqkz\{Loader, Factions};
use vLiqkz\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class TeleportHomeTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * TeleportHomeTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setTeleportingHomeTime(Loader::getDefaultConfig("Cooldowns")["Home"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
        	$this->getHandler()->cancel();
        	return;
        }
        if(!$player->isTeleportingHome()){
        	$this->getHandler()->cancel();
        	return;
        }
        if(!Factions::inFaction($player->getName())){
        	$this->getHandler()->cancel();
        	return;
        }
        if($player->getTeleportingHomeTime() === 0){
            $player->teleport(Factions::getFactionHomeLocation(Factions::getFaction($player->getName())));
            $player->setTeleportingHome(false);
            $this->getHandler()->cancel();
        }else{
            $player->setTeleportingHomeTime($player->getTeleportingHomeTime() - 1);
        }
    }
}

?>