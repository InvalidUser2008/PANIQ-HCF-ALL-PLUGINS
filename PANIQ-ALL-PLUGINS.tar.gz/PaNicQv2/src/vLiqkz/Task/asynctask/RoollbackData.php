<?php


namespace vLiqkz\Task\asynctask;

use vLiqkz\Loader;
use vLiqkz\player\{Player, PlayerBase};

use vLiqkz\item\Items;
use vLiqkz\Task\event\InvincibilityTask;

use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use pocketmine\utils\Config;

class RoollbackData extends AsyncTask {

    /** @var String */
    protected $name;

    /** @var Array[] */
    protected $items;

    /** @var Array[] */
    protected $armorItems;
    /**
     * RoollbackData Constructor.
     * @param String $name
     * @param Array $items
     * @param Array $armorItems
     * @param Config $config
     */
    public function __construct(String $name, Array $items, Array $armorItems){
        $this->name = $name;
        $this->items = $items;
        $this->armorItems = $armorItems;
    }

    /**
     * @return void
     */
    public function onRun() : void {
        $name = $this->name;
        $file = new Config(Loader::getInstance()->getDataFolder()."backups/$name");
        if($file->exists($this->name)){
            $file->remove($this->name);
        }
        foreach ($this->items as $slot => $item) {
            $fileData["items"][$slot] = Items::itemDeserialize($item);
        }
        foreach ($this->armorItems as $slot => $item) {
            $fileData["armorItems"][$slot] = Items::itemDeserialize($item);
        }
        $file->set($this->name, $fileData);
        $file->save();
    }

    /**
     * @param Server $server
     * @return void
     */
    public function onCompletion() : void {
        $server = Server::getInstance();
        $player = $server->getPlayerExact($this->name);
        if(empty($player)){
            return;
        }
        if($player instanceof Player){
            $player->setInvincibility(true);
            PlayerBase::setData($player->getName(), "pvp_time", (1 * 3600));
            Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new InvincibilityTask($player), 20);    
        }
    }
}

?>