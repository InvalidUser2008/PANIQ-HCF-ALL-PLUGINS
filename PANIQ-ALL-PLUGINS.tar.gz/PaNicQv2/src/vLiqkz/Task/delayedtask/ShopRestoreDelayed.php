<?php

namespace vLiqkz\Task\delayedtask;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use vLiqkz\shop\Shop;
use pocketmine\block\utils\SignText;
use pocketmine\tile\{Tile, Sign};
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class ShopRestoreDelayed extends Task {
	
	/** @var Tile */
    protected $tile;
    
    /** @var Shop */
    protected $shop;
	
	/**
	 * ShopRestoreDelayed Constructor.
	 * @param Tile $tile
     * @param Shop $shop
	 */
	public function __construct($tile, Shop $shop){
        $this->tile = $tile;
        $this->shop = $shop;
	}
	
	/**
	 * @param Int $currentTick
	 * @return void
	 */
	public function onRun() : void {
        $tile = $this->tile;
        $shop = $this->shop;

        $item =  (new ItemFactory)->get($shop->getId(), $shop->getDamage(), $shop->getAmount());
        if($tile instanceof Sign){
            try {
                if($shop->getType() === \vLiqkz\listeners\interact\Shop::BUY){
                    $lines = [TE::GREEN."[Shop]", TE::BLACK.$item->getName(), TE::BLACK."x".$shop->getAmount(), TE::BLACK."$".$shop->getPrice()];
					$text = new SignText($lines);
					$title->setNewText($text);
                    $this->getHandler()->cancel();
                }elseif($shop->getType() === \vLiqkz\listeners\interact\Shop::SELL){
                    $lines = [TE::RED."[Sell]", TE::BLACK.$item->getName(), TE::BLACK."x".$shop->getAmount(), TE::BLACK."$".$shop->getPrice()];
					$text = new SignText($lines);
					$title->setNewText($text);
                    $this->getHandler()->cancel();
                }
            }catch(\Exception $exception){
                Loader::getInstance()->getLogger()->error($exception->getMessage());
            }
        }
        $this->getHandler()->cancel();
	}
}

?>