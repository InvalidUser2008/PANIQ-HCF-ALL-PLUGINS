<?php

namespace vLiqkz\Task\event;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use vLiqkz\listeners\event\AIRDROP;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class AIRDROPTask extends Task {
	
	/**
	 * KEYALLTask Constructor.
	 * @param Int $time
	 */
	public function __construct(Int $time = 60){
		AIRDROP::setTime($time);
	}
	
	/**
	 * @param Int $currentTick
	 * @return void
	 */
	public function onRun() : void {
		if(!AIRDROP::isEnable()){
			$this->getHandler()->cancel();
			return;
		}
		if(AIRDROP::getTime() === 0){
			AIRDROP::setEnable(false);
			$this->getHandler()->cancel();
		}else{
			AIRDROP::setTime(AIRDROP::getTime() - 1);
		}
	}
}

?>