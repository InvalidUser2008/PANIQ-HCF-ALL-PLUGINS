<?php

namespace vLiqkz\Task\event;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use vLiqkz\listeners\event\EOTW;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class EOTWTask extends Task {
	
	/**
	 * EOTWTask Constructor.
	 * @param Int $time
	 */
	public function __construct(Int $time = 60){
		EOTW::setTime($time);
	}
	
	/**
	 * @param Int $currentTick
	 * @return void
	 */
	public function onRun() : void {
		if(!EOTW::isEnable()){
			$this->getHandler()->cancel();
			return;
		}
		if(EOTW::getTime() === 0){
			EOTW::setEnable(false);
			$this->getHandler()->cancel();
		}else{
			EOTW::setTime(EOTW::getTime() - 1);
		}
	}
}

?>