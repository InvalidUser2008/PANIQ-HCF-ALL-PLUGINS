<?php

namespace vLiqkz\Task\event;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use vLiqkz\listeners\event\KEYALLOP;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class KEYALLOPTask extends Task {
	
	/**
	 * KEYALLTask Constructor.
	 * @param Int $time
	 */
	public function __construct(Int $time = 60){
		KEYALLOP::setTime($time);
	}
	
	/**
	 * @param Int $currentTick
	 * @return void
	 */
	public function onRun() : void {
		if(!KEYALLOP::isEnable()){
			$this->getHandler()->cancel();
			return;
		}
		if(KEYALLOP::getTime() === 0){
			KEYALLOP::setEnable(false);
			$this->getHandler()->cancel();
		}else{
			KEYALLOP::setTime(KEYALLOP::getTime() - 1);
		}
	}
}

?>