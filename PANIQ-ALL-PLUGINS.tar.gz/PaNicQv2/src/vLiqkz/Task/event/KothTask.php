<?php

namespace vLiqkz\Task\event;

use vLiqkz\Loader;
use vLiqkz\player\Player;
use vLiqkz\Factions;
use vLiqkz\crate\CrateManager;

use vLiqkz\Task\asynctask\DiscordMessage;

use vLiqkz\koth\{Koth, KothManager};

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class KothTask extends Task {

    /** @var String */
    protected $kothName;

    /** @var Int */
    protected $kothTime;

    /**
     * KothTask Constructor.
     * @param String $kothName
     * @param Int $kothTime
     */
    public function __construct(String $kothName, Int $kothTime = null){
        $this->kothName = $kothName;
        $this->kothTime = $kothTime;

        Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{kothName}"], ["§", $kothName], Loader::getConfiguration("messages")->get("koth_was_started")));
        $webhook = new Webhook("");
        $msg = new Message();
        $embed = new Embed();
               
        $msg->setUsername("PaNicQ HCF | Koth Information");
        
        $embed->setDescription("Un Koth a iniciado...");
        $embed->addField("Koth", " $kothName ");       
        $embed->addField("Modalidad", "HCF");
        $embed->addField("IP:PaNicQ.ddns.net", "Port:19132");
        $embed->setColor(0xFFAA00);
        
        $msg->addEmbed($embed);
        $webhook->send($msg);
    }
    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $koth = KothManager::getKoth($this->kothName);
        if(empty($koth)){
        	$this->getHandler()->cancel();
            return;
        }
        $koth->setEnable(true);
        if(!$koth->isEnable()){
            $this->getHandler()->cancel();
            return;
        }
        if($koth->getCapturer() === null||!$koth->getCapturer()->isOnline()||(!$koth->isInPosition($koth->getCapturer()->getPosition()))){
            $koth->setCapture(false);
            $koth->setKothTime(!empty($this->kothTime) ? $this->kothTime : $koth->getDefaultKothTime());
            $koth->setCapturer(null);
            foreach(Loader::getInstance()->getServer()->getOnlinePlayers() as $player){
                if($koth->isInPosition($player->getPosition()) && !$player->isInvincibility()){
                    if(empty($koth->getCapturer())) $koth->setCapturer($player);
                }
            }
            if(!empty($koth->getCapturer())){
                if(Factions::inFaction($koth->getCapturer()->getName())){
                    $factionName = Factions::getFaction($koth->getCapturer()->getName());
                    Factions::setPoints($factionName, Factions::getPoints($factionName) + 10);
                }

                Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{kothName}", "{factionName}"], ["§", $koth->getName(), $koth->getCapturer()->getName()], Loader::getConfiguration("messages")->get("koth_is_capturing")));
            }
        }
        if($koth->getKothTime() === 0){
            if(empty($koth->getCapturer())) return;
            
            CrateManager::giveKey($koth->getCapturer(), "Koth", rand(1, 3));

            Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{kothName}", "{playerName}"], ["§", $koth->getName(), $koth->getCapturer()->getName()], Loader::getConfiguration("messages")->get("koth_is_captured")));

            # Da los puntos al jugador que capturó el koth
            # Webhook to send the message to discord
            $message = $koth->getName()." KOTH was captured by ".$koth->getCapturer()->getName();
            Loader::getInstance()->getServer()->getAsyncPool()->submitTask(new DiscordMessage(Loader::getDefaultConfig("URL"), $message, "PaNicQ | Koth Information"));

            $koth->setEnable(false);
            $this->getHandler()->cancel();
        }else{
            $koth->setKothTime($koth->getKothTime() - 1);
        }
    }
}

?>