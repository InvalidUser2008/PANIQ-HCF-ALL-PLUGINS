<?php

namespace vLiqkz\Task\event;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use vLiqkz\listeners\event\PPALL;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class PPALLTask extends Task {
	
	/**
	 * PPALLTask Constructor.
	 * @param Int $time
	 */
	public function __construct(Int $time = 60){
		PPALL::setTime($time);
	}
	
	/**
	 * @param Int $currentTick
	 * @return void
	 */
	public function onRun() : void {
		if(!PPALL::isEnable()){
			$this->getHandler()->cancel();
			return;
		}
		if(PPALL::getTime() === 0){
			PPALL::setEnable(false);
			$this->getHandler()->cancel();
		}else{
			PPALL::setTime(PPALL::getTime() - 1);
		}
	}
}

?>