<?php

namespace vLiqkz\Task\event;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use vLiqkz\listeners\event\SOTW;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class SOTWTask extends Task {
	
	/**
	 * SOTWTask Constructor.
	 * @param Int $time
	 */
	public function __construct(Int $time = 60){
		SOTW::setTime($time);
	}
	
	/**
	 * @param Int $currentTick
	 * @return void
	 */
	public function onRun() : void {
		if(!SOTW::isEnable()){
			$this->getHandler()->cancel();
			return;
		}
		foreach(Loader::getInstance()->getServer()->getOnlinePlayers() as $online){
			$online->hidePlayer($online);
		}
		if(SOTW::getTime() === 0){
			foreach(Loader::getInstance()->getServer()->getOnlinePlayers() as $online){
				$online->showPlayer($online);
			}
			SOTW::setEnable(false);
			$this->getHandler()->cancel();
		}else{
			SOTW::setTime(SOTW::getTime() - 1);
		}
	}
}

?>