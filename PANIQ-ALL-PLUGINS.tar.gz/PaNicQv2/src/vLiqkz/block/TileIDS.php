<?php

namespace vLiqkz\block;

interface TileIDS{
    
 const DISPENSER = "Dispenser";
}