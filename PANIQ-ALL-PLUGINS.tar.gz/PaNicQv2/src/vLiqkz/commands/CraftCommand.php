<?php

namespace vLiqkz\commands;

use pocketmine\block\CraftingTable;
use pocketmine\block\inventory\ChestInventory;
use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\crafting\CraftingGrid as CraftingCraftingGrid;
use pocketmine\utils\TextFormat as TE;

use pocketmine\inventory\CraftingGrid;
use pocketmine\item\Item;
use pocketmine\network\mcpe\protocol\ContainerOpenPacket;
use pocketmine\network\mcpe\protocol\types\inventory\WindowTypes as InventoryWindowTypes;
use pocketmine\network\mcpe\protocol\types\WindowTypes;

class CraftCommand extends VanillaCommand {
	
	/**
	 * CraftCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("craft", "Can open your Craft table", "craft");
        $this->setPermission("craft.command.use");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
        if(!$sender->hasPermission("craft.command.use")){
            $sender->sendMessage(TE::RED."You have not permissions to use this command");
            return;
        }
        if($sender instanceof Player){
            $pk = new ContainerOpenPacket();
            $pk->type = InventoryWindowTypes::WORKBENCH;
            $pk->x = $sender->getPosition()->getFloorX();
            $pk->y = $sender->getPosition()->getFloorY() + 5;
            $pk->z = $sender->getPosition()->getFloorZ();
            $sender->getNetworkSession()->sendDataPacket($pk);
        }
    }
}

?>