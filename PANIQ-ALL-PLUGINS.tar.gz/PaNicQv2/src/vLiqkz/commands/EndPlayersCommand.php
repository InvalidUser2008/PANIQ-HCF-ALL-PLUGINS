<?php

namespace vLiqkz\commands;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;
use pocketmine\utils\TextFormat as TE;

class EndPlayersCommand extends VanillaCommand {

    /**
     * EndPlayersCommand Constructor.
     */
    public function __construct(){
        parent::__construct("endplayers", "Can see how many players there are in the End world", "endplayers");
        $this->setPermission("endplayers.command.use");
    }

    /**
     * @param CommandSender $sender
     * @param String $label
     * @param Array $args
     * @return void
     */
    public function execute(CommandSender $sender, String $label, Array $args) : void {
        if(!$sender->hasPermission("endplayers.command.use")){
            $sender->sendMessage(TE::RED."You have not permissions to use this command");
            return;
        }
        if(!Loader::getInstance()->getServer()->getWorldManager()->isWorldGenerated(Loader::getDefaultConfig("LevelManager")["levelEndName"])){
            $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_current_world_is_disable")));
            return;
        }
        if(!Loader::getInstance()->getServer()->getWorldManager()->isWorldLoaded(Loader::getDefaultConfig("LevelManager")["levelEndName"])){
            Loader::getInstance()->getServer()->getWorldManager()->loadWorld(Loader::getDefaultConfig("LevelManager")["levelEndName"]);
        }
        $level = Loader::getInstance()->getServer()->getWorldManager()->getWorldByName(Loader::getDefaultConfig("LevelManager")["levelEndName"]);
        $sender->sendMessage(str_replace(["&", "{players}", "{worldName}"], ["§", count($level->getPlayers()), $level->getDisplayName()], Loader::getConfiguration("messages")->get("player_current_player_in_a_world")));
    }
}

?>