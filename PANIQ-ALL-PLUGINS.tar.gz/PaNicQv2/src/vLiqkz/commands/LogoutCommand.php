<?php

namespace vLiqkz\commands;

use vLiqkz\Loader;
use vLiqkz\player\Player;
use vLiqkz\Task\LogoutTask;

use pocketmine\utils\TextFormat as TE;
use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;

class LogoutCommand extends VanillaCommand {
	
	/** @var Loader */
	protected $plugin;
	
	/**
	 * LogoutCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("logout", "Can leave the server, without losing your things", "logout");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if($sender instanceof Player){
			if($sender->isLogout()){
				$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_in_logout_time")));
				return;
			}
			$sender->setLogout(true);
			$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getDefaultConfig("Cooldowns")["Logout"]], Loader::getConfiguration("messages")->get("sender_logout")));
			Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new LogoutTask($sender), 20);	
		}
	}
}

?>