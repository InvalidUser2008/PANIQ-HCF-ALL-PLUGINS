<?php

namespace vLiqkz\commands;

use vLiqkz\player\Player;

use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;
use pocketmine\utils\TextFormat as TE;

class MapCommand extends VanillaCommand {
	
	public function __construct(){
		parent::__construct("map", "Map Info");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
        
        $sender->sendMessage('§r§7');
        $sender->sendMessage('§r§eHCF Teams');
        $sender->sendMessage('§Map 1');
        $sender->sendMessage('Mens for Factions: 8');
        $sender->sendMessage('');
  }	
}

?>
