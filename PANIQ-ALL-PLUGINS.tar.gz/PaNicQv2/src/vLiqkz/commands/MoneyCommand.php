<?php

namespace vLiqkz\commands;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;
use pocketmine\utils\TextFormat as TE;

class MoneyCommand extends VanillaCommand {
	
	/**
	 * MoneyCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("money", "Can see the total sum of your money", "money");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if($sender instanceof Player){
			$sender->sendMessage(str_replace(["&", "{money}"], ["§", $sender->getBalance()], Loader::getConfiguration("messages")->get("player_total_money")));
		}
    }
}

?>