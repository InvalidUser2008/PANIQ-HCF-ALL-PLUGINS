<?php

namespace vLiqkz\commands;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;
use pocketmine\utils\TextFormat as TE;

class NetherPlayersCommand extends VanillaCommand {

    /**
     * NetherPlayersCommand Constructor.
     */
    public function __construct(){
        parent::__construct("netherplayers","Can see how many players there are in the Nether world" ,"netherplayers");
    }

    /**
     * @param CommandSender $sender
     * @param String $label
     * @param Array $args
     * @return void
     */
    public function execute(CommandSender $sender, String $label, Array $args) : void {
        if(!$sender->hasPermission("netherplayers.command.use")){
            $sender->sendMessage(TE::RED."You have not permissions to use this command");
            return;
        }
        if(!Loader::getInstance()->getServer()->getWorldManager()->isWorldGenerated(Loader::getDefaultConfig("LevelManager")["levelNetherName"])){
            $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_current_world_is_disable")));
            return;
        }
        if(!Loader::getInstance()->getServer()->getWorldManager()->isWorldLoaded(Loader::getDefaultConfig("LevelManager")["levelNetherName"])){
            Loader::getInstance()->getServer()->getWorldManager()->loadWorld(Loader::getDefaultConfig("LevelManager")["levelNetherName"]);
        }
        $level = Loader::getInstance()->getServer()->getWorldManager()->getWorldByName(Loader::getDefaultConfig("LevelManager")["levelNetherName"]);
        $sender->sendMessage(str_replace(["&", "{players}", "{worldName}"], ["§", count($level->getPlayers()), $level->getDisplayName()], Loader::getConfiguration("messages")->get("player_current_player_in_a_world")));
    }
}

?>