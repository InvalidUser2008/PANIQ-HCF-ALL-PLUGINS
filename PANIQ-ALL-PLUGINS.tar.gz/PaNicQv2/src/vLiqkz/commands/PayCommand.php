<?php

namespace vLiqkz\commands;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;
use pocketmine\utils\TextFormat as TE;

class PayCommand extends VanillaCommand {
	
	/**
	 * PayCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("pay", "Pay money to other players", "pay");
		
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(!$sender instanceof Player) return;
        if(empty($args)){
			$sender->sendMessage(TE::RED."Argument #1 is not valid for command syntax");
			return;
		}
		if(!is_numeric($args[1])){
			$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("not_is_numeric")));
			return;
		}
		if(is_float($args[1])){
			$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("not_float_number")));
			return;
		}
		$player = Loader::getInstance()->getServer()->getPlayerExact($args[0]);
		if(!$player instanceof Player) return;
		if(empty($player)){
			$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_is_online")));
			return;
		}
		if($player->getName() === $sender->getName()){
			return;
		}
		if($sender->getBalance() < $args[1]||$args[1] < 0){
			$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_money_not_enough")));
			return;
		}
		$sender->reduceBalance($args[1]);
		$player->addBalance($args[1]);
		$sender->sendMessage(str_replace(["&", "{playerName}", "{money}"], ["§", $player->getName(), $args[1]], Loader::getConfiguration("messages")->get("player_pay_money_correctly")));
	}
}

?>