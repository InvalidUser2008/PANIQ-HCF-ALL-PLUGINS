<?php

namespace vLiqkz\commands;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;


class PingCommand extends VanillaCommand {
	
	/** @var Vaute */
	protected $plugin;
	
	/**
	 * PingCommand Constructor.
	 * @param 
	 */
	public function __construct(){
		parent::__construct("ping", "/ping [string: target]", "ping");
	}
	
	public function execute(CommandSender $sender, string $label, array $args){
		if(!$sender instanceof Player){
			$sender->sendMessage(TE::RED."Use this command in the game!");
			return;
		}
		if(isset($args[0])){
			$jug = $sender->getServer()->getPlayerExact($args[0]);
			if($jug != null){
				unset($args[0]);
				$sender->sendMessage(TE::GRAY."Ping of the player ".TE::AQUA.$jug->getName().TE::GRAY." is of ".TE::AQUA.$jug->getNetworkSession()->getPing().TE::GRAY." ms..!");
			}else{
				$sender->sendMessage(TE::RED."The player you are entering is not connected!");
			}
		}else{
			$sender->sendMessage(TE::GRAY."You ping player ".TE::AQUA.$sender->getName().TE::GRAY." is of ".TE::AQUA.$sender->getNetworkSession()->getPing().TE::GRAY." ms..!");
		}
	}
}