<?php

namespace vLiqkz\commands\events;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use vLiqkz\utils\Translator;

use vLiqkz\listeners\event\KEYALL;

use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;
use pocketmine\utils\TextFormat as TE;

class KEYALLCommand extends VanillaCommand {
	
	/**
	 * KEYALLCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("keyall", "keyall Command", "keyall");
        
        //parent::setPermission("keyall.command.use");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(count($args) === 0){
			$sender->sendMessage(TE::RED."Use: /{$label} <on|off>");
			return;
		}
		if(!$sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)){
			$sender->sendMessage(TE::RED."You have not permissions to use this command");
			return;
		}
		switch($args[0]){
			case "on":
				if(!$sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
				}
				if(empty($args[1])){
					$sender->sendMessage(TE::RED."Use: /{$label} {$args[0]} [Int: time]");
					return;
				}
				if(KEYALL::isEnable()){
					$sender->sendMessage(TE::RED."The event was started before, you can't do this!");
					return;
				}
				if(!in_array(Translator::intToString($args[1]), Translator::VALID_FORMATS)){
					$sender->sendMessage(TE::RED."The time format you enter is invalid!");
					return;
				}
				KEYALL::start(Translator::getStringFormatToInt(Translator::stringToInt($args[1]), $args[1]) ?? 60);
			break;
			case "off":
				if(!$sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
				}
				if(!KEYALL::isEnable()){
					$sender->sendMessage(TE::RED."The event was never started, you can't do this!");
					return;
				}
				KEYALL::stop();
			break;
		}
	}
}

?>