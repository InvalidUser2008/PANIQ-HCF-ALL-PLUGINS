<?php

namespace vLiqkz\commands\moderation;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\entity\Creature;
use pocketmine\entity\Human;
use pocketmine\entity\object\ExperienceOrb;
use pocketmine\entity\object\ItemEntity;

use pocketmine\utils\TextFormat as TE;
use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;

class ClearEntitysCommand extends VanillaCommand {
	
	/**
	 * ClearEntitysCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("clearentitys", "ClearEntityCommand", "clearentitys");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(!$sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)){
			$sender->sendMessage(TE::RED."You have not permissions to use this command");
			return;
		}
		foreach(Loader::getInstance()->getServer()->getWorldManager()->getWorlds() as $level){
            foreach($level->getEntities() as $entity){
                if($entity instanceof ItemEntity){
                    $entity->close();
                }elseif($entity instanceof \pocketmine\entity\Entity && !$entity instanceof Human){
                    $entity->close();
                }elseif($entity instanceof ExperienceOrb){
                    $entity->close();
                }
            }
        }
        $sender->sendMessage(TE::GREEN."Entities cleaned up successfully!");
	}
}

?>