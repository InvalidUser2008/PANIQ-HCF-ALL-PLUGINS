<?php

namespace vLiqkz\commands\moderation;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\entity\effect\{Effect, EffectInstance, VanillaEffects};
use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;
use pocketmine\utils\TextFormat as TE;

class GlobalEffects extends VanillaCommand {
	
	/**
	 * GlobalEffects Constructor.
	 */
	public function __construct(){
		parent::__construct("geffects", "getEffects for eotw(Only Eotw) Puta madre", "geffects");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(!$sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)){
			$sender->sendMessage(TE::RED."You have not permissions to use this command");
			return;
		}
		$fire_resistance = new EffectInstance(VanillaEffects::FIRE_RESISTANCE(), 20 * 50000, 1);
        $speed = new EffectInstance(VanillaEffects::SPEED(), 20 * 50000, 1);
        $night_vision = new EffectInstance(VanillaEffects::NIGHT_VISION(), 20 * 50000, 1);
        $invisibility = new EffectInstance(VanillaEffects::INVISIBILITY(), 20 * 50000, 1);
        $strength = new EffectInstance(VanillaEffects::STRENGTH(), 20 * 50000, 1);
		foreach(Loader::getInstance()->getServer()->getOnlinePlayers() as $player){
			$player->addEffect($fire_resistance);
            $player->addEffect($speed);
            $player->addEffect($night_vision);
            $player->addEffect($invisibility);
            $player->addEffect($strength);
		}
		$sender->sendMessage(TE::GREEN."All effects for the ffa were given to a total of players ".TE::BOLD.TE::GOLD.count(Loader::getInstance()->getServer()->getOnlinePlayers()));
	}
}

?>