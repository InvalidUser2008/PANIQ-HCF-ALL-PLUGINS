<?php

namespace vLiqkz\commands\moderation;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;

class TpaCommand extends VanillaCommand {
	
	/**
	 * TpaCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("tpa", "tpa all users to you", "tpa");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(!$sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)){
			$sender->sendMessage(TE::RED."You have not permissions to use this command");
			return;
		}
		if(count($args) === 0){
			return;
		}
		if($args[0] == "all"){
			if(!$sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)){
				$sender->sendMessage(TE::RED."You have not permissions to use this command");
				return;
			}
			foreach(Loader::getInstance()->getServer()->getOnlinePlayers() as $players){
				$players->teleport($sender->getLocation());
			}
		}
	}
}

?>