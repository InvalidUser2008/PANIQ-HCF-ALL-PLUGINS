<?php

namespace vLiqkz\crate;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use vLiqkz\utils\Translator;

use pocketmine\utils\{Config, TextFormat as TE};
use pocketmine\item\{Item, ItemIds, ItemFactory};
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance, VanillaEnchantments};

class CrateManager {
	
	/** @var Array[] */
	public static $crate = [];
	
	/**
	 * @param String $crateName
	 * @return bool
	 */
	public static function isCrate(String $crateName) : bool {
		if(isset(self::$crate[$crateName])){
			return true;
		}else{
			return false;
		}
		return false;
	}
	
	/**
	 * @param Array $args
	 * @return void
	 */
	public static function createCrate(Array $args = []) : void {
        $block ="";
        $key = "";
        if(isset($args["block_meta"])){
            $block = $args["block_id"].":".$args["block_meta"];
            $key = $args["key_id"].":".$args["key_meta"];
        }else{
            $block = $args["block_id"].":"."0";
            $key = $args["key_id"].":"."0";
        }
        
        self::$crate[$args["name"]] = new Crate($args["name"], $args["contents"], $block, $key, $args["keyName"], $args["nameFormat"], !empty($args["position"]) ? $args["position"] : null, !empty($args["particles"]) ? $args["particles"] : null);
	}
	
	/**
	 * @param String $crateName
	 * @return void
	 */
	public static function removeCrate(String $crateName) : void {
		unset(self::$crate[$crateName]);
		$file = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."crates.yml", Config::YAML);
		$file->remove($crateName);
		$file->save();
	}

    /**
     * @param Player $player
     * @param String $crateName
     * @param Int $amount
     * @param String $spawned
     */
	public static function giveKey(Player $player, String $crateName, Int $amount = 1, String $spawned = "CONSOLE") : void {
		$crate = self::getCrate($crateName);
        $KeyInt = intval($crate->getKey());
        $KeyMetaInt = intval($crate->getKeyMeta());
		$item = (new ItemFactory)->get($KeyInt, $KeyMetaInt, $amount);
		$item->setCustomName($crate->getKeyName());
		$item->setLore(["", 
		  "§r§7Right-Click this key",
					"§r§l§eCrate §r§7located at", 
           "§eSpawn §7to obtain rewards.",
					"§r",
					"§r§7 Cosmos.tebex.io",
					"",
					]);
		$item->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 1));

		$player->getInventory()->addItem($item);
        $player->sendMessage(str_replace(["&", "{keyName}"], ["§", $crate->getKeyName()], Loader::getConfiguration("messages")->get("crate_give_key_correctly")));
	}

	/**
	 * @param String $crateName
	 * @return Crate
	 */
	public static function getCrate(String $crateName) : ?Crate {
		return self::isCrate($crateName) ? self::$crate[$crateName] : null;
	}
	
	/**
	 * @return Array
	 */
	public static function getCrates() : Array {
		return self::$crate;
	}
}

?>