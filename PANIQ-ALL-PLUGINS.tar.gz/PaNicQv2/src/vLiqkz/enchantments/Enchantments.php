<?php

namespace vLiqkz\enchantments;

use vLiqkz\Loader;
use pocketmine\data\bedrock\EnchantmentIdMap;
use vLiqkz\enchantments\command\CEnchantmentsCommand;
use vLiqkz\enchantments\type\{Speed, FireResistance, JumpBoost, Invisibility};

class Enchantments {
	
	/** @var Array[] */
	protected static $enchantments = [];

    /**
     * @return void
     */
    public static function init() : void {
        Loader::getInstance()->getServer()->getCommandMap()->register("ce", new CEnchantmentsCommand);
        EnchantmentIdMap::getInstance()->register(38, self::$enchantments["speed"] = new Speed());
        EnchantmentIdMap::getInstance()->register(39, self::$enchantments["fire_resistance"] = new FireResistance());
        EnchantmentIdMap::getInstance()->register(40, self::$enchantments["jump_boost"] = new JumpBoost());
        EnchantmentIdMap::getInstance()->register(41, self::$enchantments["invisibility"] = new Invisibility());
}
    
    /**
     * @param String $name
     * @return Enchantment
     */
    public static function getEnchantmentByName(String $name) : CustomEnchantment {
    	return self::$enchantments[$name];
    }
    
    /**
     * @return Array[]
     */
    public static function getEnchantments() : Array {
    	return self::$enchantments;
    }
}

?>