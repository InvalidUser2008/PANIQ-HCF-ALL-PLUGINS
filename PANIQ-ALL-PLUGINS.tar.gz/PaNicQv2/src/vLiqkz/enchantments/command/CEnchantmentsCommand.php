<?php

namespace vLiqkz\enchantments\command;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use vLiqkz\FormAPI\MenuForm;

use vLiqkz\enchantments\{Enchantments, CustomEnchantment};

use pocketmine\command\{CommandSender, Command};
use pocketmine\utils\TextFormat as TE;

use pocketmine\Server;
use pocketmine\item\Armor;
use pocketmine\item\enchantment\EnchantmentInstance;

class CEnchantmentsCommand extends Command {
	
	/**
	 * CEnchantmentsCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("ce", "Can enchant your armor with custom enchantments", "", []);
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(!$sender->hasPermission("cenchantments.command.use") && !Server::getInstance()->isOp($sender->getName())){
            $sender->sendMessage(Main::getConfiguration("messages")->get("not_have_permissions"));
            return;
        }
        $this->open($sender);
	}
	
	/**
	 * @param Player $player
	 */
	protected function open(Player $player){
		$form = new MenuForm(function (Player $player, $data){
			if($data === null){
				return;
			}
			$enchantment = Enchantments::getEnchantmentByName($data);
			$item = $player->getInventory()->getItemInHand();
			if($item->isNull()||!$item instanceof Armor){
				return;
			}
			if($player->getBalance() < $enchantment->getEnchantmentPrice()){
				$player->sendMessage(getConfiguration("messages")->get("player_money_not_enough"));
				return;
			}
			if($enchantment instanceof CustomEnchantment){
				$lastLore = [];
				if(!empty($item->getLore())){
					$lastLore = $item->getLore();
				}
				$lastLore[] = $enchantment->getNameWithFormat();
				$item->setLore($lastLore);
			}
			$item->addEnchantment(new EnchantmentInstance($enchantment, 1));
			
			$player->reduceBalance($enchantment->getEnchantmentPrice());
       		$player->getInventory()->setItemInHand($item);
		});
		$form->setTitle(TE::GOLD.TE::BOLD."CUSTOM ENCHANTMENTS SELECTOR!");
		foreach(array_values(Enchantments::getEnchantments()) as $enchantment){
			$form->addButton(TE::BOLD.TE::RED.$enchantment->getName().TE::RESET."\n".TE::YELLOW."Price".TE::WHITE.": ".TE::YELLOW."$".$enchantment->getEnchantmentPrice(), -1, "", $enchantment->getName());
		}
		$player->sendForm($form);
		return $form;
	}
}

?>