<?php

namespace vLiqkz\enchantments\type;

use pocketmine\utils\TextFormat as TE;

use vLiqkz\enchantments\CustomEnchantment;
use pocketmine\item\enchantment\{Rarity, ItemFlags};
use pocketmine\entity\effect\{EffectInstance, VanillaEffects};

class FireResistance extends CustomEnchantment {

    protected const ID = 38;

    /**
     * FireResistance Constructor.
     */
    public function __construct(){
        parent::__construct(self::ID, $this->getVanillaName(), Rarity::COMMON, ItemFlags::ARMOR, ItemFlags::NONE, 2);
    }

    /**
     * @return String
     */
    public function getVanillaName() : String {
        return "fire_resistance";
    }
    
    /**
     * @return String
     */
    public function getNameWithFormat() : String {
    	return TE::RESET.TE::RED."Fire Resistance";
    }

        /**
     * @return EffectInstance
     */
    public function getEffectsByEnchantment() : EffectInstance {
        return new EffectInstance(VanillaEffects::FIRE_RESISTANCE(), 60, 1);
    }
    
    /**
     * @return Int
     */
    public function getEnchantmentPrice() : Int {
    	return 10000;
   }
}

?>