<?php

namespace vLiqkz\enchantments\type;

use pocketmine\utils\TextFormat as TE;

use vLiqkz\enchantments\CustomEnchantment;
use pocketmine\item\enchantment\{Rarity, ItemFlags};
use pocketmine\entity\effect\{EffectInstance, VanillaEffects};

class Invisibility extends CustomEnchantment {

    protected const ID = 39;

    /**
     * Invisibility Constructor.
     */
    public function __construct(){
        parent::__construct(self::ID, $this->getVanillaName(), Rarity::COMMON, ItemFlags::ARMOR, ItemFlags::NONE, 2);
    }

    /**
     * @return String
     */
    public function getVanillaName() : String {
        return "invisibility";
    }
    
    /**
     * @return String
     */
    public function getNameWithFormat() : String {
    	return TE::RESET.TE::RED."Invisibility";
    }

    /**
     * @return EffectInstance
     */
    public function getEffectsByEnchantment() : EffectInstance {
        return new EffectInstance(VanillaEffects::INVISIBILITY(), 60, 1);
    }
    
    /**
     * @return Int
     */
    public function getEnchantmentPrice() : Int {
    	return 15000;
   }
}

?>