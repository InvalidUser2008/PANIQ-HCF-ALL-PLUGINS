<?php

namespace vLiqkz\enchantments\type;

use pocketmine\utils\TextFormat as TE;

use vLiqkz\enchantments\CustomEnchantment;
use pocketmine\item\enchantment\{Rarity, ItemFlags};
use pocketmine\entity\effect\{EffectInstance, VanillaEffects};

class JumpBoost extends CustomEnchantment {

    protected const ID = 40;

    /**
     * JumpBoost Constructor.
     */
    public function __construct(){
        parent::__construct(self::ID, $this->getVanillaName(), Rarity::COMMON, ItemFlags::ARMOR, ItemFlags::NONE, 2);
    }

    /**
     * @return String
     */
    public function getVanillaName() : String {
        return "jump_boost";
    }
    
    /**
     * @return String
     */
    public function getNameWithFormat() : String {
    	return TE::RESET.TE::RED."Jump Boost";
    }

    /**
     * @return EffectInstance
     */
    public function getEffectsByEnchantment() : EffectInstance {
        return new EffectInstance(VanillaEffects::JUMP_BOOST(), 60, 1);
    }
    
    /**
     * @return Int
     */
    public function getEnchantmentPrice() : Int {
    	return 15000;
   }
}

?>