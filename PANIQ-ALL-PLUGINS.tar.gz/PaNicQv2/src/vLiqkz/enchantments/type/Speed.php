<?php

namespace vLiqkz\enchantments\type;

use pocketmine\utils\TextFormat as TE;

use vLiqkz\enchantments\CustomEnchantment;
use pocketmine\item\enchantment\{Rarity, ItemFlags};
use pocketmine\entity\effect\{EffectInstance, VanillaEffects};

class Speed extends CustomEnchantment {

    protected const ID = 37;

    /**
     * Speed Constructor.
     */
    public function __construct(){
        parent::__construct(self::ID, $this->getVanillaName(), Rarity::COMMON, ItemFlags::ARMOR, ItemFlags::NONE, 2);
    }

    /**
     * @return String
     */
    public function getVanillaName() : String {
        return "speed";
    }
    
    /**
     * @return String
     */
    public function getNameWithFormat() : String {
    	return TE::RESET.TE::RED."Speed";
    }

    /**
     * @return EffectInstance
     */
    public function getEffectsByEnchantment() : EffectInstance {
        return new EffectInstance(VanillaEffects::SPEED(), 60, 1);
    }
    
    /**
     * @return Int
     */
    public function getEnchantmentPrice() : Int {
    	return 10000;
   }
}

?>