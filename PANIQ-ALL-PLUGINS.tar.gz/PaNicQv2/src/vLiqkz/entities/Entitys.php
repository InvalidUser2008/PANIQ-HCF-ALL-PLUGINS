<?php

namespace vLiqkz\entities;

use vLiqkz\Loader;
use vLiqkz\entities\ZombieBard;
use vLiqkz\entities\FakeVillager;
use vLiqkz\entities\Lightning;
use pocketmine\entity\EntityDataHelper;
use pocketmine\world\World;
use pocketmine\nbt\tag\CompoundTag;
use vLiqkz\entities\tiles\{MonsterTileSpawner};

use vLiqkz\entities\spawnable\{Cow, Enderman, Villager, Pig, Creeper, Turtle, Horse};

use pocketmine\entity\{Entity,EntityFactory};
use pocketmine\tile\Tile;
use pocketmine\data\bedrock\EntityLegacyIds;
use vLiqkz\entities\EnderPearlProjectile;
class Entitys {
	
	/**
	 * @return void
	 */
	public static function init() : void {
		EntityFactory::getInstance()->register(EnderPearlProjectile::class, function(World $world, CompoundTag $nbt) : EnderPearlProjectile {
            return new EnderPearlProjectile(EntityDataHelper::parseLocation($nbt, $world), null, $nbt);
        }, ['ThrownEnderpearl', 'minecraft:ender_pearl'], EntityLegacyIds::ENDER_PEARL);
        
		/*
		(new EntityFactory)->registerEntity(Cow::class, true, ["Cow"]);
		(new EntityFactory)->registerEntity(Enderman::class, true, ["Enderman"]);
		(new EntityFactory)->registerEntity(Villager::class, true, ["Villager"]);
		(new EntityFactory)->registerEntity(Pig::class, true, ["Pig"]);
		(new EntityFactory)->registerEntity(Creeper::class, true, ["Creeper"]);
		(new EntityFactory)->registerEntity(Turtle::class, true, ["Turtle"]);
		(new EntityFactory)->registerEntity(Horse::class, true, ["Horse"]);
        (new EntityFactory)->registerEntity(Egg::class, true, ["Egg"]);
        (new EntityFactory)->registerEntity(ZombieBard::class, true);
        (new EntityFactory)->registerEntity(FakeVillager::class, true);
		(new EntityFactory)->registerEntity(SplashPotion::class, true, ["SplashPotion"]);
		(new EntityFactory)->registerEntity(FishingHook::class, true, ["FishingHook"]);
		*/
		//Tile::register(MonsterTileSpawner::class);
	}
	
	/**
	 * @return Array[]
	 */
	public static function getEntitysType() : Array {
		return Loader::getDefaultConfig("Entitys");
	}
}

?>