<?php

namespace vLiqkz\entities;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use vLiqkz\API\projectile\Throwable;

use pocketmine\utils\TextFormat as TE;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;
use pocketmine\world\Level;
use pocketmine\nbt\tag\CompoundTag;

use pocketmine\event\entity\EntityDamageEvent;

class FishingHook extends Throwable {
	
	const NETWORK_ID = self::FISHING_HOOK ;

	/** @var float */
    public $width = 0.25, $length = 0.25, $height = 0.25;

	/** @var float */
    protected $gravity = 0.11, $drag = 0.01;
    
    /** @var bool */
    protected $hasFishing = false;
    
    /**
     * FishingHook Constructor.
     * @param Level $level
     * @param CompoundTag $nbt
     * @param Entity $shootingEntity
     */
    public function __construct(Location $level, Player $thrower, ?Entity $shootingEntity = null){
        parent::__construct($level, $thrower, $shootingEntity);
    }

    /** 
	 * @param Int $currentTick
	 * @return bool
	 */
	public function onUpdate(Int $currentTick) : bool {
		if($this->closed){
			return false;
        }

        $this->timings->startTiming();
		$hasUpdate = parent::onUpdate($currentTick);
		
		if($this->isCollided){
			$this->close();
            $hasUpdate = true;
		}
		$this->timings->stopTiming();
        return $hasUpdate;
    }
}

?>