<?php

namespace vLiqkz\entities;

use pocketmine\level\Level;
use pocketmine\entity\Entity;
use pocketmine\nbt\tag\CompoundTag;

use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;

class Lightning extends Entity {

    const NETWORK_ID = self::LIGHTNING_BOLT;

    /** @var float */
    public $width = 0.5, $length = 0.5, $height = 0.5;

	/** @var float */
    protected $gravity = 0.03, $drag = 0.01;

    /**
     * Lightning Constructor.
     * @param Level $level
     * @param CompoundTag $nbt
     * @param Entity $shootingEntity
     */
    public function __construct(Level $level, CompoundTag $nbt, ?Entity $shootingEntity = null){
        parent::__construct($level, $nbt, $shootingEntity);
    }

    /** 
	 * @param 
	 * @return bool
	 */
	public function onUpdate() : bool {
        parent::onUpdate($currentTick);
		if($this->closed){
			return false;
        }
        $this->getLevel()->broadcastLevelSoundEvent($this, LevelSoundEventPacket::SOUND_THUNDER);
        $this->getLevel()->broadcastLevelSoundEvent($this, LevelSoundEventPacket::SOUND_EXPLODE);
        $this->getLevel()->broadcastLevelSoundEvent($this, LevelSoundEventPacket::SOUND_THUNDER);

        $this->timings->startTiming();
		
		if($this->isCollided){
            $this->close();
		}
		$this->timings->stopTiming();
		return true;
    }
}

?>