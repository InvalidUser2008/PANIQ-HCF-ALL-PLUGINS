<?php
/*
* Copyright (C) Sergittos - All Rights Reserved
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential
*/

declare(strict_types=1);


namespace vLiqkz\item;

use vLiqkz\Task\EnderPearlTask;
use pocketmine\entity\Location;
use pocketmine\entity\projectile\Throwable;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemIds;
use pocketmine\item\ItemUseResult;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use vLiqkz\cooldowns\Cooldowns;

class EnderPearl extends \pocketmine\item\EnderPearl {

    public function __construct() {
        parent::__construct(new ItemIdentifier(ItemIds::ENDER_PEARL, 0), "Ender Pearl");
    }
    public function onClickAir(Player $player, Vector3 $directionVector): ItemUseResult {
        if(Cooldowns::getMain()->has($player->getName(), "EnderPearl")){
            $timeleft = Cooldowns::getMain()->get($player->getName(), "EnderPearl");
            $player->sendMessage("§eThe Ender Pearl Is On Cooldown Left: {$timeleft}");
            return ItemUseResult::FAIL();
        }
        Cooldowns::getMain()->add($player->getName(), 10, "EnderPearl");
        $location = $player->getLocation();
        $projectile = $this->createEntity(Location::fromObject($player->getEyePos(), $player->getWorld(), $location->yaw, $location->pitch), $player);
		$projectile->setMotion($directionVector->multiply($this->getThrowForce()));
        $this->pop(1);
        return ItemUseResult::SUCCESS();
    }
    protected function createEntity(Location $location, Player $thrower): Throwable {
        return new \vLiqkz\entities\EnderPearlProjectile($location, $thrower);
    }
    public function getThrowForce(): float {
        return 2.1;
    }
    public function addCount(int $count): EnderPearl {
        $this->setCount($count);
        return $this;
    }
}