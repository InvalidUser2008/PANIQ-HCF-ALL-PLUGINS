<?php

namespace vLiqkz\item;

use pocketmine\entity\effect\Effect;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\item\Food;
use pocketmine\item\{ItemIds, ItemIdentifier, VanillaItems};
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\entity\Location;
use pocketmine\entity\projectile\Throwable;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Living;

class GoldenAppleEnchanted extends GoldenApple {
	
	/**
	 * GoldenAppleEnchanted Constructor.
	 * @param Int $meta
	 */
	public function __construct(Int $meta = 0){
		$item = new ItemIdentifier(ItemIds::ENCHANTED_GOLDEN_APPLE, $meta);
		Food::__construct($item, "Enchanted Golden Apple");
	}
	public function onConsume(Living $consumer): void
	{
	}
	/**
	 * @return Array
	 */
	public function getAdditionalEffects() : Array {
		return [
			new EffectInstance(VanillaEffects::REGENERATION(), 600, 4),
			new EffectInstance(VanillaEffects::ABSORPTION(), 2400, 3),
			new EffectInstance(VanillaEffects::RESISTANCE(), 6000),
			new EffectInstance(VanillaEffects::FIRE_RESISTANCE(), 6000)
		];
	}
}

?>