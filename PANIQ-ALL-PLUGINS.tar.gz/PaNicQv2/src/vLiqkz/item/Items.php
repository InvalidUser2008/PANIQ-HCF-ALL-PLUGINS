<?php

namespace vLiqkz\item;

use pocketmine\entity\EntityFactory;
use vLiqkz\item\specials\{Firework,
    SecondChance,
    RemoveEffect,
    StormBreaker,
    AntiTrapper,
    EggPorts,
    Strength,
    Resistance,
    Invisibility,
    PotionCounter,
    NinjaShear,
    LoggerBait,
    RageBrick,
    RareBrick,
    Berserk,
    Energy,
    Medkit,                        
    Cactus,
    PartnerPackages,
    ZombieBardItem
};

use vLiqkz\item\netherite\{Helmet, Chestplate, Leggings, Boots, Sword, Pickaxe};

use pocketmine\item\{Item, ItemFactory};

class Items {

	const NETHERITE_HELMET = 748, NETHERITE_CHESTPLATE = 749, NETHERITE_LEGGINGS = 750, NETHERITE_BOOTS = 751, NETHERITE_SWORD = 743, NETHERITE_PICKAXE = 745;
	
	/**
	 * @return void
	 */
	public static function init() : void {
        ItemFactory::getInstance()->register(new EnderPearl(), true);
        
		ItemFactory::getInstance()->register(new GoldenApple(), true);
		ItemFactory::getInstance()->register(new GoldenAppleEnchanted(), true);
		ItemFactory::getInstance()->register(new EnderEye(), true);

	}

	/**
	 * @param Item $item
	 * @return Array[]
	 */
	public static function itemSerialize(Item $item) : Array {
		$data = $item->jsonSerialize();
		return $data;
	}

	/**
	 * @param Array $items
	 * @return Item
	 */
	public static function itemDeserialize(Array $items) : Item {
		$item = Item::jsonDeserialize($items);
		return $item;
	}
}

?>