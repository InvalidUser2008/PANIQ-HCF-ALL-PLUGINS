<?php

namespace vLiqkz\item\specials;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\ItemIds;
class AntiTrapper extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	const USES_LEFT = "Uses left";
	
	/**
	 * StormBreaker Constructor.
	 * @param Int $usesLeft
	 */
	public function __construct(Int $usesLeft = 5){
		parent::__construct(ItemIds::BLAZE_ROD, TE::GOLD.TE::BOLD."Anti-Blockup", [TE::RESET."\n".TE::GRAY."When you hit a player with this".TE::GRAY."\n".TE::GRAY."they may not blockup for 15 seconds".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in the".TE::GREEN." Item ".TE::WHITE."crate"."\n\n".TE::YELLOW."Uses Left: ".TE::GOLD.$usesLeft]);
		$CompoundTag = CompoundTag::create(self::CUSTOM_ITEM);
		$this->setNamedTag($CompoundTag);
		$this->getNamedTag(self::CUSTOM_ITEM)->setInt(self::USES_LEFT, $usesLeft);
	}
	
	/**
	 * @param Player $player
	 * @return void
	 */
	public function reduceUses(Player $player) : void {
		$nbt = $this->setNamedTag(self::CUSTOM_ITEM)->getInt(self::USES_LEFT);
		if($nbt > 0){
			$nbt--;
			if($nbt === 0){
				$player->getInventory()->setItemInHand(self::get(self::AIR));
			}else{
				$this->setNamedTag(self::CUSTOM_ITEM)->setInt(self::USES_LEFT, $nbt);
				$this->setLore([TE::RESET."\n".TE::GRAY."When you hit a player with this".TE::GRAY."\n".TE::GRAY."they may not blockup for 15 seconds".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in the".TE::GREEN." Item ".TE::WHITE."crate"."\n\n".TE::YELLOW."Uses Left: ".TE::GOLD.$nbt]);
				$player->getInventory()->setItemInHand($this);
			}
		}
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 1;
    }
}

?>