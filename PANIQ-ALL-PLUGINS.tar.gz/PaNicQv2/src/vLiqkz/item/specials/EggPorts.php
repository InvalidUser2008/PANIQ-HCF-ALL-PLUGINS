<?php

namespace vLiqkz\item\specials;
use pocketmine\entity\projectile\Throwable;
use pocketmine\event\entity\ProjectileHitEntityEvent;
use vLiqkz\Loader;

use vLiqkz\player\Player;
use pocketmine\math\Vector3;
use pocketmine\entity\Location;
use pocketmine\utils\TextFormat as TE;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\{ItemIds, ItemUseResult};
use pocketmine\entity\projectile\Egg as EggEntity;
use pocketmine\event\entity\ProjectileLaunchEvent;
class EggPorts extends CustomProjectileItem {
	
	const CUSTOM_ITEM = "CustomItem";
	
	/**
	 * EggPorts Constructor.
	 */
	public function __construct(){
		$CompoundTag = CompoundTag::create(self::CUSTOM_ITEM);
		$this->setNamedTag($CompoundTag);
		$this->setLore([TE::RESET."\n".TE::GRAY."Switch places with your".TE::GRAY."\n".TE::GRAY."enemy that is within 7 blocks".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in the".TE::GREEN." Item ".TE::WHITE."crate"]);
		parent::__construct(ItemIds::EGG, TE::LIGHT_PURPLE.TE::BOLD."Eggport", [TE::RESET."\n".TE::GRAY."Switch places with your".TE::GRAY."\n".TE::GRAY."enemy that is within 7 blocks".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in the".TE::GREEN." Item ".TE::WHITE."crate"]);
	}
	public function onClickAir(\pocketmine\player\Player $player, \pocketmine\math\Vector3 $directionVector): \pocketmine\item\ItemUseResult{
        if($this->isEgg($player)){ // is in cooldown
			$player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getEggTime())], Loader::getConfiguration("messages")->get("eggport_cooldown")));
            return ItemUseResult::FAIL();
        }
        $location = $player->getLocation();
		//set Cooldown
        $projectile = new EggEntity(Location::fromObject($player->getEyePos(), $player->getWorld(), $location->yaw, $location->pitch), $player);
        $projectile->setMotion($directionVector->multiply(5.8));

        $projectileEv = new ProjectileLaunchEvent($projectile);
        $projectileEv->call();
        if($projectileEv->isCancelled()) {
            $projectile->flagForDespawn();
            return ItemUseResult::FAIL();
        }

        $projectile->spawnToAll();
        $this->pop();
        $this->updateCooldown();

        $location->getWorld()->addSound($location, new ThrowSound());
        return ItemUseResult::SUCCESS();
    }

    public function onThrow(Player $player, Player $victim): void {
        $player_position = $player->getPosition();
        $victim_position = $victim->getPosition();
        if($player_position->distance($victim_position) > 8) {
            return;
        }
        $player->teleport($victim_position);
        $victim->teleport($player_position);
    }


	public function createEntity(\pocketmine\entity\Location $location, \pocketmine\player\Player $thrower) : Throwable{
		return new EggEntity($location, $thrower);
	}

	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 16;
	}
	
	/**
	 * @return String
	 */
	public function getProjectileEntityType() : String {
		return "Egg";
	}
	
	/**
	 * @return float
	 */
	public function getThrowForce() : float {
        return 2.0;
	}

    /**
     * @param Player $player
     * @param Vector3 $directionVector
     */
	
}

?>