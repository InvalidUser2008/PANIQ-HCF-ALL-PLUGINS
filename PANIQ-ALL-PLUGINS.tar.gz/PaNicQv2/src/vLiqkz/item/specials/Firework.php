<?php

namespace vLiqkz\item\specials;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\ItemIds;
class Firework extends Custom {

    const CUSTOM_ITEM = "CustomItem";

    /**
     * Firework constructor.
     */
    public function __construct(){
        parent::__construct(ItemIds::FIREWORKS, TE::DARK_PURPLE.TE::BOLD."Firework", [TE::RESET."\n".TE::GRAY."Use this to Raise".TE::GRAY."\n".TE::GRAY."Yourself up in the sky".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in the".TE::GREEN." Item ".TE::WHITE."crate"]);
        		$CompoundTag = CompoundTag::create(self::CUSTOM_ITEM);
		$this->setNamedTag($CompoundTag);
    }
}

?>