<?php

namespace vLiqkz\item\specials;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\ItemIds;
class LoggerBait extends Custom {

    const CUSTOM_ITEM = "CustomItem";

    /**
     * Invisibility Constructor.
     */
    public function __construct(){
        parent::__construct(ItemIds::SPAWN_EGG, TE::YELLOW.TE::BOLD."LoggerBait", [TE::RESET."\n".TE::GRAY."This item simulates a".TE::GRAY."\n".TE::GRAY."lack of disconnection".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in the".TE::GREEN." Item ".TE::WHITE."crate"]);
        		$CompoundTag = CompoundTag::create(self::CUSTOM_ITEM);
		$this->setNamedTag($CompoundTag);
    }

    /**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 64;
    }
}

?>