<?php

namespace vLiqkz\item\specials;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use vLiqkz\item\EnderPearl;

use pocketmine\utils\TextFormat as TE;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\ItemIds;
class PrePearl extends CustomProjectileItem {
	
	const CUSTOM_ITEM = "CustomItem";
	
	/**
	 * PrePearl Constructor.
	 */
	public function __construct(){
		parent::__construct(ItemIds::ENDER_PEARL, "PrePearl", [TE::GREEN.TE::BOLD."RARE ITEM".TE::RESET."\n\n".TE::GRAY."Can return to the position in which you activated the PrePearl"]);
		$CompoundTag = CompoundTag::create(self::CUSTOM_ITEM);
		$this->setNamedTag($CompoundTag);
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 16;
	}
}

?>