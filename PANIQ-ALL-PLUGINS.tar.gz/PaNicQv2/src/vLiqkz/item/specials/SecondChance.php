<?php

namespace vLiqkz\item\specials;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\ItemIds;
class SecondChance extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	/**
	 * SecondChance Constructor.
	 */
	public function __construct(){
		parent::__construct(ItemIds::IRON_NUGGET, TE::AQUA.TE::BOLD."SecondChance", [TE::RESET."\n".TE::GRAY."This item will reset".TE::GRAY."\n".TE::GRAY."your EnderPearl Cooldown".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in the".TE::GREEN." Item ".TE::WHITE."crate"]);
				$CompoundTag = CompoundTag::create(self::CUSTOM_ITEM);
		$this->setNamedTag($CompoundTag);
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 64;
    }
}

?>