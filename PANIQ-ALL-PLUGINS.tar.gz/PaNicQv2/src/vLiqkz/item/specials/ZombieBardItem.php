<?php

namespace vLiqkz\item\specials;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\ItemIds;
class ZombieBardItem extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	/**
	 * ZombieBard Constructor.
	 */
	public function __construct(){
		parent::__construct(ItemIds::GLOWSTONE_DUST, "§6Portable Bard", [TE::GOLD.TE::BOLD."LEGENDARY ITEM".TE::RESET."\n\n".TE::GRAY."Zombie Bard portable, same as the Bard"]);
				$CompoundTag = CompoundTag::create(self::CUSTOM_ITEM);
		$this->setNamedTag($CompoundTag);
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 64;
    }
}

?>