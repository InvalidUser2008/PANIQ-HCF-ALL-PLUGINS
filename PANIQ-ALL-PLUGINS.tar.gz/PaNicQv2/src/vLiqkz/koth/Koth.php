<?php

namespace vLiqkz\koth;

use vLiqkz\player\Player;
use vLiqkz\utils\Translator;
use pocketmine\Server;
use pocketmine\world\Position;

class Koth {

    /** @var String */
    protected $name;

    /** @var Player */
    protected $capturer;

    /** @var Int */
    protected $kothTime;

    /** @var bool */
    protected $capture = false;

    /** @var Array[] */
    protected $position1 = [];

    /** @var Array[] */
    protected $position2 = []; 

    /** @var String */
    protected $level;

    /** @var bool */
    protected $enable = false;

    /**
     * Koth Constructor.
     * @param String $name
     * @param Array $position1
     * @param Array $position2
     */
    public function __construct(String $name, Array $position1, Array $position2, String $level){
        $this->name = $name;
        $this->level = $level;
        $this->position1 = $position1;
        $this->position2 = $position2;
    }

    /**
     * @return String
     */
    public function getName() : String {
        return $this->name;
    }

    /**
     * @param String $name
     */
    public function setName(String $name){
        $this->name = $name;
    }

    /**
     * @return String
     */
    public function getWorld() : String {
        return $this->level;
    }

    /**
     * @param String $level
     */
    public function setLevel(String $level){
        $this->level = $level;
    }

    /**
     * @return Int
     */
    public function getKothTime() : Int {
        return $this->kothTime;
    }
    
    /**
     * @param Int $kothTime
     */
    public function setKothTime(Int $kothTime){
        $this->kothTime = $kothTime;
    }

    /**
     * @return Int
     */
    public function getDefaultKothTime() : Int {
        return 5 * 60 + 1;
    }

    /**
     * @return Position
     */
    public function getPosition1() : Position {
        return $this->arrayToPosition($this->position1);
    }

    public function arrayToPosition(Array $pos) : ?Position {
        if(count($pos) < 2) return null;
        $value = new Position($pos[0], $pos[1], $pos[2], Server::getInstance()->getWorldManager()->getDefaultWorld());
        return $value;
    }

    public function positionToArray(Position $position) : Array {
        $value = [$position->x, $position->y, $position->z];
        return $value;
    }

    /**
     * @param Position $position1
     */
    public function setPosition1(Position $position1){
        $this->position1 = $this->positionToArray($position1);
    }

    /**
     * @return Position
     */
    public function getPosition2() : Position {
        return $this->arrayToPosition($this->position2);
    }

    /**
     * @param Position $position2
     */
    public function setPosition2(Position $position2){
        $this->position2 = $this->positionToArray($position2);
    }

    /**
     * @param Position $player
     * @return bool
     */
    public function isInPosition(Position $position) : bool {
        $x = $position->getFloorX();
        $y = $position->getFloorY();
        $z = $position->getFloorZ();

        $xMin = min($this->getPosition1()->getFloorX(), $this->getPosition2()->getFloorX());
        $xMax = max($this->getPosition1()->getFloorX(), $this->getPosition2()->getFloorX());

        $yMin = min($this->getPosition1()->getFloorY(), $this->getPosition2()->getFloorY());
        $yMax = max($this->getPosition1()->getFloorY(), $this->getPosition2()->getFloorY());

        $zMin = min($this->getPosition1()->getFloorZ(), $this->getPosition2()->getFloorZ());
        $zMax = max($this->getPosition1()->getFloorZ(), $this->getPosition2()->getFloorZ());

        return $x >= $xMin && $x <= $xMax && $y >= $yMin && $y <= $yMax && $z >= $zMin && $z <= $zMax; 
    }

    /**
     * @return bool
     */
    public function isCapture() : bool {
        return $this->capture;
    }

    /**
     * @param bool $capture
     */
    public function setCapture(bool $capture){
        $this->capture = $capture;
    }

    /**
     * @return bool
     */
    public function isEnable() : bool {
        return $this->enable;
    }

    /**
     * @param bool $enable
     */
    public function setEnable(bool $enable){
        $this->enable = $enable;
    }

    /**
     * @param Player $player
     */
    public function setCapturer(?Player $player){
        $this->capturer = $player;
    }

    /**
     * @return Player
     */
    public function getCapturer() : ?Player {
        return $this->capturer;
    }
}

?>