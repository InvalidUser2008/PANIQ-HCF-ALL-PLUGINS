<?php

namespace vLiqkz\listeners;

use vLiqkz\{Loader, Factions};
use vLiqkz\player\Player;

use vLiqkz\API\System;
use vLiqkz\utils\Tower;
use pocketmine\block\BlockFactory;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TE;
use pocketmine\math\Vector3;
use pocketmine\block\Block;

use pocketmine\event\player\{PlayerChatEvent, PlayerInteractEvent, PlayerDropItemEvent};
use pocketmine\event\block\BlockBreakEvent;

class Claim implements Listener {

    /**
     * Claim Constructor.
     */
    public function __construct(){
        
    }

    /**
     * @param PlayerDropItemEvent $event
     * @return void
     */
    public function onPlayerDropItemEvent(PlayerDropItemEvent $event) : void {
        $player = $event->getPlayer();
        if(!$player instanceof Player) return;
        if($player->isInteract() && $player->getInventory()->getItemInHand()->getCustomName() === TE::GREEN."Claiming Wand"){
            $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_drop_tool")));
            $event->cancel();
        }
    }

    /**
     * @param PlayerInteractEvent $event
     * @return void
     */
    public function onPlayerInteractEvent(PlayerInteractEvent $event) : void {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $spawn = new Vector3(0, 0, 0);
        if(!$player instanceof Player) return;
        if($player->isInteract() && $player->getInventory()->getItemInHand()->getCustomName() === TE::GREEN."Claiming Wand" && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
            $event->cancel();
            if((int)$spawn->distance($block->getPosition()) < 400 && !$player->isGodMode()){
                $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_small_distance_of_spawn")));
                $event->cancel();
                return;
            }
            if(!System::isPosition($player, 1)){
                $player->sendMessage(str_replace(["&", "{positionX}", "{positionZ}"], ["§", $block->getPosition()->getFloorX(), $block->getPosition()->getFloorZ()], Loader::getConfiguration("messages")->get("faction_location_zone_first")));
                Tower::delete($player, 1);
                $glass = (new BlockFactory)->get(20, 0);
                Tower::create($block, $player, $glass);
                System::setPosition($player, $block, 1);
                $event->cancel();
            }
        }
    }

    /**
     * @param BlockBreakEvent $event
     * @return void
     */
    public function onBlockBreakEvent(BlockBreakEvent $event) : void {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $spawn = new Vector3(0, 0, 0);
        if(!$player instanceof Player) return;
        if($player->isInteract() && $player->getInventory()->getItemInHand()->getCustomName() === TE::GREEN."Claiming Wand"){
            $event->cancel();
            if((int)$spawn->distance($block->getPosition()) < 400 && !$player->isGodMode()){
                $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_small_distance_of_spawn")));
                $event->cancel();
                return;
            }
            if(!System::isPosition($player, 1)) return;

            $player->sendMessage(str_replace(["&", "{positionX}", "{positionZ}"], ["§", $block->getPosition()->getFloorx(), $block->getPosition()->getFloorZ()], Loader::getConfiguration("messages")->get("faction_location_zone_second")));
            Tower::delete($player, 2);
            System::deletePosition($player, 2);
            $glass = (new BlockFactory)->get(20, 0);
            Tower::create($block, $player, $glass);
            System::setPosition($player, $block, 2);
            System::checkClaim($player, System::getPosition($player, 1), System::getPosition($player, 2));
            $event->cancel();
        }
    }

    /**
     * @param PlayerChatEvent $event
     * @return void
     */
    public function onPlayerChatEvent(PlayerChatEvent $event) : void {
        $player = $event->getPlayer();
        if(!$player instanceof Player) return;
        if($player->isInteract() && $event->getMessage() === "accept"){
            if(Factions::getBalance(Factions::getFaction($player->getName())) < $player->getClaimCost()){
                $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_not_have_money_for_claim_zone")));
                $event->cancel();
                return;
            }
            if(!System::isPosition($player, 1) && !System::isPosition($player, 2)){
                $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_zone_not_select_position")));
                return;
            }
            Factions::claimRegion(Factions::getFaction($player->getName()), $player->getWorld()->getDisplayName(), System::getPosition($player, 1), System::getPosition($player, 2), Factions::FACTION);
            Factions::reduceBalance(Factions::getFaction($player->getName()), $player->getClaimCost());

            Tower::delete($player, 1);
            Tower::delete($player, 2);
            System::deletePosition($player, 1, true);
            System::deletePosition($player, 2, true);
            $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_zone_accept")));
            $event->cancel();
        }
        if($player->isInteract() && $event->getMessage() === "cancel"){
            Tower::delete($player, 1);
            Tower::delete($player, 2);
            System::deletePosition($player, 1, true);
            System::deletePosition($player, 2, true);
            $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_zone_cancel")));
            $event->cancel();
        }
    }
}

?>