<?php

namespace vLiqkz\listeners;

use vLiqkz\Loader;
use vLiqkz\Factions;
use vLiqkz\player\Player;
use vLiqkz\utils\NBT;
use vLiqkz\entities\Lightning;

use vLiqkz\Task\asynctask\RoollbackData;

use pocketmine\event\Listener;
use pocketmine\entity\Entity;

use pocketmine\utils\{Config, TextFormat as TE};

use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\entity\{EntityDamageEvent, EntityDamageByEntityEvent};

class Death implements Listener {
	
	/**
	 * Death Constructor.
	 */
	public function __construct(){
		
	}
	
	/**
	 * @param PlayerDeathEvent $event
	 * @return void
	 */
	public function onPlayerDeathEvent(PlayerDeathEvent $event) : void {
		$player = $event->getPlayer();
		if($player instanceof Player){
			if($player->getLastDamageCause() instanceof EntityDamageByEntityEvent){
				$damager = $player->getLastDamageCause()->getDamager();
				if($damager instanceof Player){
					$damager->addKills();
                }
                
				if (Factions::inFaction($player->getName())) {
				    Factions::setPoints(Factions::getFaction($player->getName()), Factions::getPoints(Factions::getFaction($player->getName())) -1);
                }
                if (Factions::inFaction($damager->getName())) {
                    Factions::setPoints(Factions::getFaction($damager->getName()), Factions::getPoints(Factions::getFaction($damager->getName())) +2);
                }
				Loader::getInstance()->getServer()->getAsyncPool()->submitTask(new RoollbackData($player->getName(), $player->getInventory()->getContents(), $player->getArmorInventory()->getContents(), new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."inventory.yml", Config::YAML)));
				$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::GRAY."[".TE::YELLOW.$player->getKills().TE::GRAY."]".TE::YELLOW." was killed by ".TE::RESET.TE::RED.$damager->getName().TE::GRAY."[".TE::YELLOW.$damager->getKills().TE::GRAY."]".TE::YELLOW." using ".TE::AQUA.$damager->getInventory()->getItemInHand()->getName());
			}else{
				if($player->getLastDamageCause() === null) return;
				switch($player->getLastDamageCause()->getCause()){
					case EntityDamageEvent::CAUSE_FALL:
						
						$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::YELLOW." fell from a high place!");
					break;
					case EntityDamageEvent::CAUSE_DROWNING:
						
						$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::YELLOW." drowned!");
					break;
					case EntityDamageEvent::CAUSE_FIRE:
						
						$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::YELLOW." died burned!");
					break;
					case EntityDamageEvent::CAUSE_FIRE_TICK:
						
						$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::YELLOW." died burned!");
					break;
					case EntityDamageEvent::CAUSE_LAVA:
						
						$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::YELLOW." died in lava!");
					break;
					case EntityDamageEvent::CAUSE_BLOCK_EXPLOSION:
						
						$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::YELLOW." it seems to explode!");
					break;
					case EntityDamageEvent::CAUSE_ENTITY_EXPLOSION:
						
						$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::YELLOW." it seems to explode!");
					break;
					case EntityDamageEvent::CAUSE_SUICIDE:
						
						$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::YELLOW." committed suicide!");
					break;
					case EntityDamageEvent::CAUSE_SUFFOCATION:
						
						$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::YELLOW." he died suffocated!");
					break;
					case EntityDamageEvent::CAUSE_VOID:
						
						$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::YELLOW." fell from the world!");
					break;
				}
			}
		}
	}
}

?>