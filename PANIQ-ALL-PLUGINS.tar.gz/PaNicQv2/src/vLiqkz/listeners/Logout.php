<?php

namespace vLiqkz\listeners;

use vLiqkz\{Loader, Factions};
use vLiqkz\player\Player;

use Advanced\Data\PlayerBase;

use vLiqkz\entities\spawnable\Villager;

use pocketmine\entity\Entity;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\match\Vecor3;
use pocketmine\world\Position;
class Logout implements Listener {
	

	/**
	 * Logout Constructor.
	 */
	public function __construct(){

	}
	
	/**
	 * @param PlayerQuitEvent
	 *  $event
	 * @return void
	 */
	public function onPlayerQuitEvent(PlayerQuitEvent $event) : void {
		$player = $event->getPlayer();
		if(!$player instanceof Player) return;
		if($player->isCombatTag()||!$player->isLogout()){
			if(Factions::isSpawnRegion($player)) return;
			//more code of staff, latter ;)
			if($player->isCombatTag()){
				$inventory = $player->getInventory()->getContents();

				foreach($inventory as $slot => $item) {
					$player->dropItem($item);
				}
				$player->kill();
			}
			
			
		}
	}
}

?>