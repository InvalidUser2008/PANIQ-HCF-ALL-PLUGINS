<?php

namespace vLiqkz\listeners\interact;

use vLiqkz\Loader;
use vLiqkz\player\Player;

use pocketmine\block\tile\Sign;
use pocketmine\math\Vector3;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TE;

use pocketmine\block\Air;

use pocketmine\event\block\SignChangeEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\block\utils\SignText;
class Elevators implements Listener {

    const ELEVATOR_UP = "up", ELEVATOR_DOWN = "down";

    /**
     * Elevators Constructor.
     */
    public function __construct(){
        
    }

    /**
	 * @param SignChangeEvent $event
	 * @return void
	 */
	public function onSignChangeEvent(SignChangeEvent $event) : void {
		if($event->getNewText()->getLine(0) !== "[elevator]"){
			return;
		}
		if($event->getNewText()->getLine(1) === "up"||$event->getNewText()->getLine(1) === "Up"||$event->getNewText()->getLine(1) === "down"||$event->getNewText()->getLine(1) === "Down"){
			$lines = [TE::RED."[Elevator]", $event->getNewText()->getLine(1)];
			$text = new SignText($lines);
			$event->setNewText($text);
		}
	}
	
	/**
	 * @param PlayerInteractEvent $event
	 * @return void
	 */
	public function onInteractEvent(PlayerInteractEvent $event) : void {
		$player = $event->getPlayer();
		$block = $event->getBlock();
		$level = Loader::getInstance()->getServer()->getWorldManager()->getDefaultWorld();
		$diff = $level->getTileAt($block->getPosition()->getX(), $block->getPosition()->getY(), $block->getPosition()->getZ());
		if($diff instanceof Sign){
			if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
				$line = $diff->getText();
				if($line->getLine(0) === TE::RED."[Elevator]"){
					if($line->getLine(1) === "up"){
						$this->teleportToSign($player, new Vector3($block->getPosition()->getX(), $block->getPosition()->getY(), $block->getPosition()->getZ()), $this->getSignText($line->getLine(1)));
					}elseif($line->getLine(1) === "down"){
						$this->teleportToSign($player, new Vector3($block->getPosition()->getX(), $block->getPosition()->getY(), $block->getPosition()->getZ()), $this->getSignText($line->getLine(1)));
					}
				}
			}
		}
	}
	
	/**
	 * @param Int $x
	 * @param Int $y
	 * @param Int $z
	 * @return null|Int
	 */
	protected function getTextDown(Int $x, Int $y, Int $z){
		$level = Loader::getInstance()->getServer()->getWorldManager()->getDefaultWorld();
		for($i = $y - 1; $i >= 0; $i--){
			$pos1 = $level->getBlockAt($x, $i, $z);
			$pos2 = $level->getBlockAt($x, $i + 1, $z);
			if($pos1 instanceof Air && $pos2 instanceof Air){
				return $i;
			}
		}
		return $y;
	}
	
	/**
	 * @param Int $x
	 * @param Int $y
	 * @param Int $z
	 * @return null|Int
	 */
	protected function getTextUp(Int $x, Int $y, Int $z){
		$level = Loader::getInstance()->getServer()->getWorldManager()->getDefaultWorld();
		for($i = $y + 1; $i <= 256; $i++){
			$pos1 = $level->getBlockAt($x, $i, $z);
			$pos2 = $level->getBlockAt($x, $i + 1, $z);
			if($pos1 instanceof Air && $pos2 instanceof Air){
				return $i;
			}
		}
		return $y;
	}
	
	/**
	 * @param Int $x
	 * @param Int $y
	 * @param Int $z
	 * @return bool
	 */
	protected function isSign(String $signType, Int $x, Int $y, Int $z) : bool {
		$default = false;
		$level = Loader::getInstance()->getServer()->getWorldManager()->getDefaultWorld();
		if($signType === self::ELEVATOR_UP){
			for($i = $y + 1; $i <= 256; $i++){
				$pos1 = $level->getBlockAt($x, $i, $z);
				$pos2 = $level->getBlockAt($x, $i + 1, $z);
				if($pos1 instanceof Air && $pos2 instanceof Air){
					$default = true;
				}
			}
		}elseif($signType === self::ELEVATOR_DOWN){
			for($i = $y - 1; $i >= 0; $i--){
				$pos1 = $level->getBlockAt($x, $i, $z);
				$pos2 = $level->getBlockAt($x, $i + 1, $z);
				if($pos1 instanceof Air && $pos2 instanceof Air){
					$default = true;
				}
			}
		}
		return $default;
	}
	
	/**
	 * @param String $singType
	 * @return null|String
	 */
	protected function getSignText(String $signType) : ?String {
		if($signType === "up"){
			return self::ELEVATOR_UP;
		}
		if($signType === "down"){
			return self::ELEVATOR_DOWN;
		}
		return self::ELEVATOR_UP;
	}
	
	/**
	 * @param Player $player
	 * @param Vector3 $position
	 * @param String $signType
	 */
	protected function teleportToSign(Player $player, Vector3 $position, String $signType = self::ELEVATOR_UP){
		if($this->isSign($signType, $position->getX(), $position->getY(), $position->getZ())){
			if($signType === self::ELEVATOR_UP){
				$location = $this->getTextUp($position->getX(), $position->getY(), $position->getZ());
				$player->teleport(new Vector3($position->getX() + 0.5, $location, $position->getZ() + 0.5, $player->getPosition()->getWorld()));
			}elseif($signType === self::ELEVATOR_DOWN){
				$location = $this->getTextDown($position->getX(), $position->getY(), $position->getZ());
				$player->teleport(new Vector3($position->getX() + 0.5, $location, $position->getZ() + 0.5, $player->getPosition()->getWorld()));
			}
		}
	}
}

?>