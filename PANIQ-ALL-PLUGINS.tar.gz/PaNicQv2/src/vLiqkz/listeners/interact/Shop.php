<?php

namespace vLiqkz\listeners\interact;

use vLiqkz\Loader;
use vLiqkz\player\Player;
use pocketmine\block\utils\SignText;
use vLiqkz\Task\delayedtask\ShopRestoreDelayed;
use vLiqkz\shop\{ShopManager, ShopBackup};

use vLiqkz\utils\Translator;

use pocketmine\event\Listener;
use pocketmine\math\Vector3;

use pocketmine\utils\{Config, TextFormat as TE};
use pocketmine\item\{ItemFactory};

use pocketmine\event\block\{BlockBreakEvent, SignChangeEvent};
use pocketmine\block\{SignPost, WallSign};
use pocketmine\block\tile\Sign as TileSign;
use pocketmine\event\player\PlayerInteractEvent;

class Shop implements Listener {
	
	const BUY = "BUY", SELL = "SELL";
	
	/**
	 *  Shop Constructor.
	 */
	public function __construct(){
		
	}
	
	/**
	 * @param PlayerInteractEvent $event
	 * @return void
	 */
	public function onInteractEvent(PlayerInteractEvent $event) : void {
		$player = $event->getPlayer();
		$block = $event->getBlock();
		if(!$player instanceof Player) return;
			if(ShopManager::isShop(Translator::vector3ToString($block))){
				$shop = ShopManager::getShop(Translator::vector3ToString($block));
				if($shop->getType() === self::SELL){
                    $item = ItemFactory::getInstance()->get($shop->getId(), $shop->getDamage(), $shop->getAmount());
					if($player->getInventory()->contains($item)){

						$tile = $player->getPosition()->getWorld()->getTile($block->getPosition());
						if($tile instanceof TileSign){
                           	$lines = [TE::GREEN."SOLD ".TE::RESET.TE::BLACK.$shop->getAmount(), TE::RESET.TE::BLACK."for ".TE::GREEN."$".$shop->getPrice(), TE::RESET.TE::BLACK."New Balance: ", TE::GREEN.$player->getBalance()];
							$text = new SignText($lines);
							$tile->setText($text);
						}

						$player->getInventory()->removeItem($item);
						$player->addBalance($shop->getPrice());

						$player->sendMessage(str_replace(["&", "{itemName}"], ["§", $item->getName()], Loader::getConfiguration("messages")->get("shop_successfully_sold_the_item")));
						Loader::getInstance()->getScheduler()->scheduleDelayedTask(new ShopRestoreDelayed($tile, $shop), 10);
					}else{
						$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("shop_dont_have_that_item")));
					}
				}
				if($shop->getType() === self::BUY){
					if($player->getBalance() < $shop->getPrice()){
						$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("shop_dont_have_money_to_buy_the_item")));
						$event->cancel();
						return;
					}
                    $item1 = ItemFactory::getInstance()->get($shop->getId(), $shop->getDamage());
					if(!$player->getInventory()->canAddItem($item1)){
						$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("shop_inventory_is_full")));
						$event->cancel();
						return;
					}

					$item =  ItemFactory::getInstance()->get($shop->getId(), $shop->getDamage(), $shop->getAmount());
					$tile = $player->getPosition()->getWorld()->getTile($block->getPosition());
					if($tile instanceof TileSign){
                        $lines1 = [TE::GREEN."BOUGHT ".TE::RESET.TE::BLACK.$shop->getAmount(), TE::RESET.TE::BLACK."for ".TE::GREEN."$".$shop->getPrice(), TE::RESET.TE::BLACK."New Balance: ", TE::GREEN.$player->getBalance()];
							$text1 = new SignText($lines1);
							$tile->setText($text1);
					}

					$player->getInventory()->addItem($item);
					$player->reduceBalance($shop->getPrice());

					$player->sendMessage(str_replace(["&", "{itemName}"], ["§", $item->getName()], Loader::getConfiguration("messages")->get("shop_correctly_bought_the_item")));
					Loader::getInstance()->getScheduler()->scheduleDelayedTask(new ShopRestoreDelayed($tile, $shop), 10);
				}
			}
			
		
}
	
	
	/**
	 * @param BlockBreakEvent $event
	 * @return void
	 */
	public function onBlockBreak(BlockBreakEvent $event) : void {
		$player = $event->getPlayer();
		$block = $event->getBlock();
		if(ShopManager::isShop(Translator::vector3ToString($block))){
			if($player->getServer()->isOp($player->getName())){
				ShopManager::removeShop(Translator::vector3ToString($block));
                ShopBackup::saveAll();
				$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("shop_remove_correctly")));
			}
		}
	}
	
	/**
	 * @param SignChangeEvent $event
	 * @return void
	 */
	public function onSignChangeEvent(SignChangeEvent $event) : void {
		$player = $event->getPlayer();
        $block = $event->getSign();

		if($player->getServer()->isOp($player->getName())){
			if($event->getNewText()->getLine(0) == "" || $event->getNewText()->getLine(1) == "" || $event->getNewText()->getLine(2) == "" || $event->getNewText()->getLine(3) == "") return;
            $itemId = 1;
            $itemMeta = 0;
            if(strpos($event->getNewText()->getLine(1), ":")){
                $arr = explode($event->getNewText()->getLine(1), ":");
                $itemId = intval($arr[0]);
                $itemMeta = intval($arr[1]);
            }else{
                $itemId = intval($event->getNewText()->getLine(1));
                $itemMeta = 0;
            }
			$item = ItemFactory::getInstance()->get($itemId,$itemMeta);
			if(strtolower($event->getNewText()->getLine(0)) === "buy"){
				if(!is_numeric($event->getNewText()->getLine(2)) && !is_numeric($event->getNewText()->getLine(3))){
					$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("shop_has_an_error")));
					return;
				}

			    $shopData = [
			        "shop_type" => self::BUY,
                    "shop_id" => $item->getId(),
                    "shop_damage" => $item->getMeta(),
                    "shop_amount" => $event->getNewText()->getLine(2),
                    "shop_price" => $event->getNewText()->getLine(3),
                    "position" => Translator::vector3ToString($block),
                ];
				ShopManager::createShop($shopData);
                ShopBackup::saveAll();
                $lines2 = [TE::GREEN."[Shop]", TE::BLACK.$item->getName(), TE::BLACK."x".$event->getNewText()->getLine(2), TE::BLACK."$".$event->getNewText()->getLine(3)];
				$text2 = new SignText($lines2);
				$event->setNewText($text2);

				$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("shop_create_correctly")));
				
			}elseif(strtolower($event->getNewText()->getLine(0)) === "sell"){
				if(!is_numeric($event->getNewText()->getLine(2)) && !is_numeric($event->getNewText()->getLine(3))){
					$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("shop_has_an_error")));
					return;
				}

                $shopData = [
                    "shop_type" => self::SELL,
                    "shop_id" => $item->getId(),
                    "shop_damage" => $item->getMeta(),
                    "shop_amount" => $event->getNewText()->getLine(2),
                    "shop_price" => $event->getNewText()->getLine(3),
                    "position" => Translator::vector3ToString($block),
                ];
                ShopManager::createShop($shopData);
                ShopBackup::saveAll();
				$lines3 = [TE::RED."[Sell]", TE::BLACK.$item->getName(), TE::BLACK."x".$event->getNewText()->getLine(2), TE::BLACK."$".$event->getNewText()->getLine(3)];
				$text3 = new SignText($lines3);
				$event->setNewText($text3);
				$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("shop_create_correctly")));
			}
		}	
	}
}
?>